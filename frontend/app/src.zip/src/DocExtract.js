import { useState, useRef, useCallback, useEffect, use } from "react";
import {BrainCircuit, Play, User, Bell, Shield, KeyRound, CreditCard, Plus, LayoutGrid, Hash, Clock3, Trash2, Activity, DollarSign, ShieldCheck, FileText, Calendar, Users, Type, Wand2, FilePlus2, CheckSquare, Mail, Building2, CalendarDays, MessageSquare, AlertCircle, ChevronDown, ChevronRight, Check, Save, Download, Eye, EyeOff, CheckCircle, AlertTriangle, Info, RefreshCw, Clock } from "lucide-react";
import * as XLSX from "xlsx";
import "./DocExtract.css";
import { History } from "./history";
import { Dashboard } from "./Dashboard";
import { Integration } from "./integration";
import { Profile } from "./Profile";
import BillingSettings from "./Billing";
import * as pdfjsLib from "pdfjs-dist/build/pdf";

pdfjsLib.GlobalWorkerOptions.workerSrc = "/pdf.worker.min.js";

const BACKEND_URL = "http://localhost:5000/api";



// ── PRESETS ───────────────────────────────────────────────────────────────────
const PRESETS_POLICY_CHECKING = [
  {
    label: "Policy Number",
    field: "Policy Number",
    prompt: "Extract the policy number exactly as it appears. Return only the policy number string, no surrounding text.",
  },
  {
    label: "Name Insured",
    field: "Name Insured",
    prompt: "Extract the primary named insured. Return the full legal name as a string.",
  },
  {
    label: "Policy Period",
    field: "Policy Period",
    prompt: "Extract the policy period dates. Return in format MM/DD/YYYY to MM/DD/YYYY.",
  },
  {
    label: "Premium",
    field: "Premium",
    prompt: "Extract the total premium amount including any breakdowns. Return as a string with dollar sign.",
  },
  {
    label: "Issuing Company",
    field: "Issuing Company",
    prompt: "Extract the name of the insurance company issuing this policy.",
  },
  {
    label: "Mailing Address",
    field: "Mailing Address",
    prompt: "Extract the mailing address of the named insured. Return as a single formatted address string.",
  },
  {
    label: "Deductible",
    field: "Deductible",
    prompt: "Extract all deductible amounts and types. Return as a string or object with labels and values.",
  },
  {
    label: "Endorsements",
    field: "Endorsements",
    prompt: "Extract all endorsements — list changes, additions, deletions, and modifications. Return as an array of strings.",
  },
  {
    label: "Forms & Endorsements",
    field: "Forms and Endorsements",
    prompt: "Extract all form numbers and titles from the Forms and Endorsements section. Format each as: FormNumber | MM/YY Form Title. Return as array.",
  },
];

const PRESETS_FINANCE = [
  {
    label: "Revenue",
    field: "Revenue",
    prompt: "Extract the total revenue or total income for the period from the Profit & Loss statement or Income Statement. Look for 'Total Revenue', 'Total Income', 'Net Revenue', or 'Revenue from operations'. Return only the numerical value."
  },
  {
    label: "Net Income",
    field: "Net Income",
    prompt: "Extract the net income or profit attributable to shareholders from the Profit & Loss statement. Look for 'Net Income', 'Profit for the period', 'Profit after tax', or 'Earnings for the period'. Return only the numerical value."
  },
  {
    label: "Gross Profit",
    field: "Gross Profit",
    prompt: "Extract gross profit from the Profit & Loss statement. Look for 'Gross Profit' line item. Return only the numerical value."
  },
  {
    label: "Operating Income",
    field: "Operating Income",
    prompt: "Extract operating income from the Profit & Loss statement. Look for 'Operating Income', 'Operating Profit', 'EBIT', or 'Profit before depreciation'. Return only the numerical value."
  },
  {
    label: "EBITDA",
    field: "EBITDA",
    prompt: "Extract EBITDA if explicitly stated in the document. If not found calculate them."
  },
  {
    label: "Cost of Goods Sold",
    field: "Cost of Goods Sold",
    prompt: "Extract the cost of goods sold (COGS) from the Profit & Loss statement. Return only the numerical value."
  },
  {
    label: "Total Debt",
    field: "Total Debt",
    prompt: "Extract total debt from the Balance Sheet. This is the sum of long-term debt, current maturities of long-term debt, and short-term borrowings. Return only the total numerical value."
  },
  {
    label: "Interest Expense",
    field: "Interest Expense",
    prompt: "Extract total interest expense from the Profit & Loss statement. Look for 'Interest Expense' or 'Finance costs'. Return only the numerical value."
  },
  {
    label: "Cash and Cash Equivalents",
    field: "Cash and Cash Equivalents",
    prompt: "Extract cash and cash equivalents from the Balance Sheet under Current Assets. Look for 'Cash and cash equivalents' or similar. Return only the numerical value."
  },
  {
    label: "Operating Cash Flow",
    field: "Operating Cash Flow",
    prompt: "Extract the net cash from operating activities from the Cash Flow Statement. Look for 'Net Cash Generated by Operating Activities' or similar. Return only the numerical value."
  },
  {
    label: "Capital Expenditure",
    field: "Capital Expenditure",
    prompt: "Extract capital expenditure from the Cash Flow Statement under Investing Activities. Look for 'Payment towards capital expenditure' or 'Capital Expenditure'. Return only the numerical value."
  },
  {
    label: "Free Cash Flow",
    field: "Free Cash Flow",
    prompt: "Extract free cash flow if explicitly stated in the document. If not found, return null. Do NOT calculate it."
  },
  {
    label: "Total Assets",
    field: "Total Assets",
    prompt: "Extract total assets from the Balance Sheet. Look for the 'Total Assets' line at the end of the assets section. Return only the numerical value."
  },
  {
    label: "Total Liabilities",
    field: "Total Liabilities",
    prompt: "Extract total liabilities from the Balance Sheet. Look for the total of all current and non-current liabilities. Return only the numerical value."
  },
  {
    label: "Current Assets",
    field: "Current Assets",
    prompt: "Extract current assets from the Balance Sheet. Look for 'Total Current Assets' line. Return only the numerical value."
  },
  {
    label: "Current Liabilities",
    field: "Current Liabilities",
    prompt: "Extract current liabilities from the Balance Sheet. Look for 'Total Current Liabilities' line. Return only the numerical value."
  },
  {
    label: "Company Name",
    field: "Company Name",
    prompt: "Extract the full legal name of the company as it appears at the top of the financial statements."
  },
  {
    label: "Fiscal Year",
    field: "Fiscal Year",
    prompt: "Extract the fiscal year or reporting year from the financial statement. Return as YYYY (e.g., 2024)."
  },
  {
    label: "period",
    field: "Period",
    prompt: "Extract the exact reporting period from the financial statement. Return in format 'Month DD, YYYY to Month DD, YYYY' (e.g., 'January 1, 2024 to December 31, 2024')."
  },
  {
    label: "Working Capital",
    field: "Working Capital",
    prompt: "Extract working capital if explicitly stated in the document. If not found, return null. Do NOT calculate it."
  }
];

const PRESETS_LEGAL = [
  {
    label: "Document Type",
    field: "Document Type",
    prompt: "Identify the type of legal document (e.g., agreement, contract, NDA, lease, policy, judgment)."
  },
  {
    label: "Document Title",
    field: "Document Title",
    prompt: "Extract the full title of the document as stated on the first page."
  },
  {
    label: "Effective Date",
    field: "Effective Date",
    prompt: "Extract the effective date of the agreement. Return in format MM/DD/YYYY."
  },
  {
    label: "Execution Date",
    field: "Execution Date",
    prompt: "Extract the date on which the document was signed. Return in format MM/DD/YYYY."
  },
  {
    label: "Governing Law",
    field: "Governing Law",
    prompt: "Extract the governing law clause from the document. Return the jurisdiction or state that governs the agreement."
  },
  {
    label: "Jurisdiction",
    field: "Jurisdiction",
    prompt: "Extract the jurisdiction clause from the document. Return the location where legal disputes would be resolved."
  },
  {
    label: "Parties Involved",
    field: "Parties Involved",
    prompt: "Extract the names of all parties involved in the agreement. Return as an array of strings."
  },
  {
    label: "Addresses",
    field: "Addresses",
    prompt: "Extract the addresses of all parties involved. Return as an array of strings."
  },
  {
    label: "Terms and Conditions",
    field: "Terms and Conditions",
    prompt: "Extract the main terms and conditions of the agreement. Return as a summarized string or array of key points."
  },
  {
    label: "Scope of Agreement",
    field: "Scope of Agreement",
    prompt: "Extract the scope of the agreement. Return as a summarized string or array of key points describing what the agreement covers."
  }
];

const PRESETS_HEALTHCARE_DOCUMENTS = [
  {
    label: "Patient Name",
    field: "Patient Name",
    prompt: "Identify the patient’s full name from the document. Prefer the primary patient record section. Return only the name string.",
  },
  {
    label: "Patient ID / UHID",
    field: "Patient ID",
    prompt: "Extract the patient identifier such as UHID, Patient ID, or MRN. Return exact value as shown.",
  },
  {
    label: "Age / Gender",
    field: "Demographics",
    prompt: "Extract patient age and gender. Return in format: Age, Gender (e.g., 45, Male).",
  },
  {
    label: "Hospital Name",
    field: "Hospital Name",
    prompt: "Extract the name of the hospital or healthcare provider issuing this document.",
  },
  {
    label: "Doctor Name",
    field: "Doctor Name",
    prompt: "Extract the primary doctor or consultant name associated with the patient.",
  },
  {
    label: "Admission Date",
    field: "Admission Date",
    prompt: "Extract the hospital admission date. Return in standard date format.",
  },
  {
    label: "Discharge Date",
    field: "Discharge Date",
    prompt: "Extract the discharge date. Return in standard date format.",
  },
  {
    label: "Diagnosis",
    field: "Diagnosis",
    prompt: "Identify the final diagnosis or clinical impression. Prefer discharge summary or conclusion section. Return concise medical terms.",
  },
  {
    label: "Procedures / Treatments",
    field: "Procedures",
    prompt: "Extract procedures, surgeries, or treatments performed. Return as a list of medical procedures.",
  },
  {
    label: "Medications",
    field: "Medications",
    prompt: "Extract prescribed medications including name, dosage, and frequency if available. Return as structured list.",
  },
  {
    label: "Lab Test Results",
    field: "Lab Results",
    prompt: "Extract key lab test results including test name, value, and units. Return as structured array.",
  },
  {
    label: "Bill Number",
    field: "Bill Number",
    prompt: "Extract hospital bill or invoice number. Return exact value.",
  },
  {
    label: "Bill Date",
    field: "Bill Date",
    prompt: "Extract billing date from the document.",
  },
  {
    label: "Total Bill Amount",
    field: "Total Amount",
    prompt: "Extract the final total amount payable for the hospital bill. Prefer grand total or net payable.",
  },
  {
    label: "Room Charges",
    field: "Room Charges",
    prompt: "Extract room or bed charges. Include duration if mentioned.",
  },
  {
    label: "Doctor Fees",
    field: "Doctor Fees",
    prompt: "Extract consultation or doctor fees.",
  },
  {
    label: "Medicine Charges",
    field: "Medicine Charges",
    prompt: "Extract total cost of medicines billed.",
  },
  {
    label: "Lab Charges",
    field: "Lab Charges",
    prompt: "Extract laboratory or diagnostic charges.",
  },
  {
    label: "Surgery Charges",
    field: "Surgery Charges",
    prompt: "Extract surgical or operation charges if present.",
  },
  {
    label: "Insurance Provider",
    field: "Insurance Provider",
    prompt: "Extract insurance company name if mentioned.",
  },
  {
    label: "Policy Number",
    field: "Policy Number",
    prompt: "Extract insurance policy number if available.",
  },
  {
    label: "Claim Amount",
    field: "Claim Amount",
    prompt: "Extract claimed amount submitted to insurance.",
  },
  {
    label: "Approved Amount",
    field: "Approved Amount",
    prompt: "Extract amount approved by insurance if available.",
  },
  {
    label: "Discharge Summary",
    field: "Discharge Summary",
    prompt: "Extract a concise summary of patient condition, treatment given, and outcome from discharge summary section.",
  },
  {
    label: "Follow-up Instructions",
    field: "Follow-up",
    prompt: "Extract follow-up instructions including medications, lifestyle advice, or revisit schedule.",
  },
  {
    label: "Document Type",
    field: "Document Type",
    prompt: "Classify document type (e.g., hospital bill, discharge summary, lab report, prescription). Return single label.",
  }
];

const PRESETS_MSA_EXTRACTION = [
  {
    label: "Agreement Title",
    field: "Agreement Title",
    prompt: "Extract the full title of the agreement as stated on the first page. Return exact text.",
  },
  {
    label: "Effective Date",
    field: "Effective Date",
    prompt: "Identify the effective date of the agreement. Prefer phrases like 'Effective Date'. Return only the date.",
  },
  {
    label: "Execution Date",
    field: "Execution Date",
    prompt: "Extract the date on which the agreement was signed by the parties.",
  },
  {
    label: "Party A Name",
    field: "Party A",
    prompt: "Extract the full legal name of the first party. Prefer the introductory clause. Return exact name.",
  },
  {
    label: "Party B Name",
    field: "Party B",
    prompt: "Extract the full legal name of the second party. Return exact name.",
  },
  {
    label: "Party Roles",
    field: "Party Roles",
    prompt: "Identify roles of each party (e.g., Client, Service Provider, Vendor). Return mapping of party name to role.",
  },
  {
    label: "Registered Addresses",
    field: "Addresses",
    prompt: "Extract registered addresses of all parties. Return as structured list.",
  },
  {
    label: "Scope of Services",
    field: "Scope of Services",
    prompt: "Extract the scope of services describing what services are to be provided. Prefer 'Scope' or 'Services' section.",
  },
  {
    label: "Service Levels (SLA)",
    field: "Service Levels",
    prompt: "Extract any service level commitments such as uptime, response time, or performance metrics.",
  },
  {
    label: "Term / Duration",
    field: "Term",
    prompt: "Extract contract duration including start date and end date or duration period.",
  },
  {
    label: "Renewal Terms",
    field: "Renewal Terms",
    prompt: "Extract renewal or extension conditions including auto-renewal if mentioned.",
  },
  {
    label: "Payment Terms",
    field: "Payment Terms",
    prompt: "Extract payment terms including fees, schedule, and conditions. Preserve structure.",
  },
  {
    label: "Pricing / Fees",
    field: "Fees",
    prompt: "Extract pricing details, fees, or rate cards mentioned in the agreement.",
  },
  {
    label: "Invoicing Terms",
    field: "Invoicing Terms",
    prompt: "Extract invoicing frequency, billing cycle, and payment timelines.",
  },
  {
    label: "Termination Clause",
    field: "Termination",
    prompt: "Extract termination conditions including notice period and termination triggers.",
  },
  {
    label: "Confidentiality Clause",
    field: "Confidentiality",
    prompt: "Extract confidentiality or non-disclosure obligations between parties.",
  },
  {
    label: "Limitation of Liability",
    field: "Liability",
    prompt: "Extract limitation of liability clause including caps or exclusions.",
  },
  {
    label: "Indemnification",
    field: "Indemnification",
    prompt: "Extract indemnification obligations including which party indemnifies whom.",
  },
  {
    label: "Intellectual Property Rights",
    field: "IP Rights",
    prompt: "Extract clauses related to ownership of intellectual property created or used.",
  },
  {
    label: "Data Protection / Privacy",
    field: "Data Protection",
    prompt: "Extract data protection, privacy, or data handling clauses.",
  },
  {
    label: "Compliance Requirements",
    field: "Compliance",
    prompt: "Extract regulatory or legal compliance obligations mentioned.",
  },
  {
    label: "Dispute Resolution",
    field: "Dispute Resolution",
    prompt: "Extract dispute resolution mechanism such as arbitration, mediation, or courts.",
  },
  {
    label: "Governing Law",
    field: "Governing Law",
    prompt: "Extract governing law or jurisdiction clause.",
  },
  {
    label: "Force Majeure",
    field: "Force Majeure",
    prompt: "Extract force majeure clause including covered events.",
  },
  {
    label: "Assignment Clause",
    field: "Assignment",
    prompt: "Extract whether rights or obligations can be assigned to third parties.",
  },
  {
    label: "Subcontracting",
    field: "Subcontracting",
    prompt: "Extract terms related to subcontracting or third-party service providers.",
  },
  {
    label: "Amendments",
    field: "Amendments",
    prompt: "Extract how the agreement can be modified or amended.",
  },
  {
    label: "Exclusivity",
    field: "Exclusivity",
    prompt: "Extract exclusivity obligations if any.",
  },
  {
    label: "Penalties / Liquidated Damages",
    field: "Penalties",
    prompt: "Extract penalties, service credits, or liquidated damages.",
  },
  {
    label: "Signatories",
    field: "Signatories",
    prompt: "Extract names and titles of signatories.",
  },
  {
    label: "Signature Dates",
    field: "Signature Dates",
    prompt: "Extract dates associated with each signature.",
  },
  {
    label: "Document Type",
    field: "Document Type",
    prompt: "Classify document as Master Service Agreement (MSA) or related agreement.",
  }
];

const PRESETS_SOW_EXTRACTION = [
  {
    label: "Document Title",
    field: "Document Title",
    prompt: "Extract the full title of the document. Prefer first page header. Return exact text.",
  },
  {
    label: "SOW Reference Number",
    field: "SOW Number",
    prompt: "Extract the Statement of Work reference or identification number if available.",
  },
  {
    label: "Effective Date",
    field: "Effective Date",
    prompt: "Extract the effective or start date of this SOW. Return only the date.",
  },
  {
    label: "Related Agreement",
    field: "Master Agreement Reference",
    prompt: "Extract reference to the governing agreement (e.g., MSA number or title).",
  },
  {
    label: "Client Name",
    field: "Client",
    prompt: "Extract the client or customer name. Return full legal name.",
  },
  {
    label: "Service Provider Name",
    field: "Service Provider",
    prompt: "Extract the vendor/service provider name. Return full legal name.",
  },
  {
    label: "Project Name",
    field: "Project Name",
    prompt: "Extract project name or engagement title if mentioned.",
  },
  {
    label: "Scope of Work",
    field: "Scope",
    prompt: "Extract detailed description of work to be performed. Prefer 'Scope of Work' section.",
  },
  {
    label: "Deliverables",
    field: "Deliverables",
    prompt: "Extract all deliverables with descriptions. Return as structured list.",
  },
  {
    label: "Milestones",
    field: "Milestones",
    prompt: "Extract project milestones including names, dates, and associated deliverables. Return structured list.",
  },
  {
    label: "Timeline / Schedule",
    field: "Timeline",
    prompt: "Extract project timeline including start date, end date, and key phases.",
  },
  {
    label: "Service Location",
    field: "Location",
    prompt: "Extract location where services will be performed (onsite, offshore, or address).",
  },
  {
    label: "Resource Requirements",
    field: "Resources",
    prompt: "Extract details of required personnel, roles, or team composition.",
  },
  {
    label: "Roles & Responsibilities",
    field: "Responsibilities",
    prompt: "Extract responsibilities of each party. Return structured mapping if possible.",
  },
  {
    label: "Dependencies / Assumptions",
    field: "Dependencies",
    prompt: "Extract assumptions or dependencies required for successful execution.",
  },
  {
    label: "Pricing Model",
    field: "Pricing Model",
    prompt: "Identify pricing model (fixed price, time & materials, milestone-based).",
  },
  {
    label: "Fees / Cost",
    field: "Fees",
    prompt: "Extract total project cost or fee structure. Include breakdown if available.",
  },
  {
    label: "Payment Schedule",
    field: "Payment Schedule",
    prompt: "Extract payment schedule linked to milestones or timelines.",
  },
  {
    label: "Invoicing Terms",
    field: "Invoicing",
    prompt: "Extract invoicing frequency, billing process, and payment timelines.",
  },
  {
    label: "Acceptance Criteria",
    field: "Acceptance Criteria",
    prompt: "Extract criteria for acceptance of deliverables.",
  },
  {
    label: "Change Request Process",
    field: "Change Management",
    prompt: "Extract process for handling scope changes or change requests.",
  },
  {
    label: "Termination Conditions",
    field: "Termination",
    prompt: "Extract termination conditions specific to this SOW.",
  },
  {
    label: "Risk / Issues",
    field: "Risks",
    prompt: "Extract identified risks, issues, or mitigation plans.",
  },
  {
    label: "Service Level Agreements",
    field: "SLA",
    prompt: "Extract SLA metrics such as response time, uptime, or delivery timelines.",
  },
  {
    label: "Confidentiality Reference",
    field: "Confidentiality",
    prompt: "Extract confidentiality obligations or references to governing agreement.",
  },
  {
    label: "Signatories",
    field: "Signatories",
    prompt: "Extract names and titles of authorized signatories.",
  },
  {
    label: "Signature Dates",
    field: "Signature Dates",
    prompt: "Extract dates associated with signatures.",
  },
  {
    label: "Document Type",
    field: "Document Type",
    prompt: "Classify document as Statement of Work (SOW). Return single label.",
  }
];

// ── PDF HIGHLIGHT VIEWER ───────────────────────────────────────────────────────
// Renders a PDF using PDF.js with text-search highlights.
// Props:
//   url          – blob URL of the PDF
//   searchText   – the extracted value string to highlight (or null/empty)
//   activeField  – field name string shown in the header pill
function PdfHighlightViewer({ url, searchText, activeField }) {
  const containerRef = useRef(null);
  const pdfDocRef = useRef(null);
  const renderTaskRef = useRef(null);

  const [totalPages, setTotalPages] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [scale, setScale] = useState(1.4);
  const [matchInfo, setMatchInfo] = useState({ count: 0, page: null });

  useEffect(() => {
    let cancelled = false;

    const loadPdf = async () => {
      if (!url) {
        pdfDocRef.current = null;
        setTotalPages(0);
        setCurrentPage(1);
        return;
      }

      try {
        const pdfjsLib = await import("pdfjs-dist/build/pdf");

        const loadingTask = pdfjsLib.getDocument(url);
        const pdf = await loadingTask.promise;

        if (cancelled) return;

        pdfDocRef.current = pdf;
        setTotalPages(pdf.numPages);
        setCurrentPage(1);
      } catch (err) {
        console.error("PDF load error:", err);
        pdfDocRef.current = null;
        setTotalPages(0);
      }
    };

    loadPdf();

    return () => {
      cancelled = true;
      if (renderTaskRef.current) {
        try {
          renderTaskRef.current.cancel();
        } catch {}
      }
    };
  }, [url]);

  useEffect(() => {
    let cancelled = false;

    const findMatches = async () => {
      const pdf = pdfDocRef.current;

      if (!pdf || !searchText || !searchText.trim()) {
        setMatchInfo({ count: 0, page: null });
        return;
      }

      try {
        const needle = searchText.trim().toLowerCase().slice(0, 40);
        let firstPage = null;
        let total = 0;

        for (let p = 1; p <= pdf.numPages; p++) {
          const page = await pdf.getPage(p);
          const textContent = await page.getTextContent();
          const pageText = textContent.items.map((i) => i.str || "").join(" ").toLowerCase();

          if (pageText.includes(needle)) {
            total += 1;
            if (!firstPage) firstPage = p;
          }

          if (cancelled) return;
        }

        if (!cancelled) {
          setMatchInfo({ count: total, page: firstPage });
          if (firstPage) setCurrentPage(firstPage);
        }
      } catch (err) {
        console.error("Search error:", err);
        if (!cancelled) setMatchInfo({ count: 0, page: null });
      }
    };

    findMatches();

    return () => {
      cancelled = true;
    };
  }, [searchText, url]);

  useEffect(() => {
    let cancelled = false;

    const renderPage = async () => {
      const pdf = pdfDocRef.current;
      const container = containerRef.current;

      if (!pdf || !container) return;

      try {
        if (renderTaskRef.current) {
          try {
            renderTaskRef.current.cancel();
          } catch {}
        }

        const pdfjsLib = await import("pdfjs-dist/build/pdf");
        const page = await pdf.getPage(currentPage);
        const viewport = page.getViewport({ scale });

        container.innerHTML = "";
        container.style.position = "relative";
        container.style.width = `${viewport.width}px`;
        container.style.height = `${viewport.height}px`;
        container.style.margin = "0 auto";

        const canvas = document.createElement("canvas");
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        canvas.style.display = "block";
        canvas.style.width = `${viewport.width}px`;
        canvas.style.height = `${viewport.height}px`;

        container.appendChild(canvas);

        const ctx = canvas.getContext("2d");
        const renderTask = page.render({
          canvasContext: ctx,
          viewport,
        });

        renderTaskRef.current = renderTask;
        await renderTask.promise;

        if (cancelled) return;

        const textContent = await page.getTextContent();
        if (cancelled) return;

        const textLayerDiv = document.createElement("div");
        textLayerDiv.style.position = "absolute";
        textLayerDiv.style.left = "0";
        textLayerDiv.style.top = "0";
        textLayerDiv.style.width = `${viewport.width}px`;
        textLayerDiv.style.height = `${viewport.height}px`;
        textLayerDiv.style.pointerEvents = "none";
        textLayerDiv.style.overflow = "hidden";

        container.appendChild(textLayerDiv);

        const needle = searchText?.trim()?.toLowerCase()?.slice(0, 40) || "";

        textContent.items.forEach((item) => {
          if (!item.str || !item.str.trim()) return;

          const tx = pdfjsLib.Util.transform(viewport.transform, item.transform);
          const x = tx[4];
          const y = tx[5];
          const fontHeight = Math.sqrt(tx[2] * tx[2] + tx[3] * tx[3]) || 12;

          const span = document.createElement("span");
          span.textContent = item.str;
          span.style.position = "absolute";
          span.style.left = `${x}px`;
          span.style.top = `${viewport.height - y}px`;
          span.style.fontSize = `${fontHeight}px`;
          span.style.fontFamily = "sans-serif";
          span.style.whiteSpace = "pre";
          span.style.color = "transparent";
          span.style.transformOrigin = "left top";
          span.style.pointerEvents = "none";

          const itemText = item.str.toLowerCase();
          if (needle && itemText.includes(needle)) {
            span.style.background = "rgba(250, 204, 21, 0.45)";
            span.style.outline = "1.5px solid rgba(234, 179, 8, 0.7)";
            span.style.borderRadius = "2px";
          }

          textLayerDiv.appendChild(span);
        });

        if (needle) {
          const firstHighlight = [...textLayerDiv.querySelectorAll("span")].find(
            (el) => el.style.background.includes("250, 204, 21")
          );
          if (firstHighlight) {
            setTimeout(() => {
              firstHighlight.scrollIntoView({ block: "center", behavior: "smooth" });
            }, 80);
          }
        }
      } catch (err) {
        if (err?.name !== "RenderingCancelledException") {
          console.error("Render error:", err);
        }
      }
    };

    renderPage();

    return () => {
      cancelled = true;
      if (renderTaskRef.current) {
        try {
          renderTaskRef.current.cancel();
        } catch {}
      }
    };
  }, [currentPage, scale, searchText, url]);

  if (!url) {
    return <div className="dv-pdf-fallback">PDF preview unavailable</div>;
  }

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        height: "100%",
        background: "#f8f8f8",
        borderRadius: "12px",
        overflow: "hidden",
      }}
    >
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "8px",
          padding: "8px 12px",
          background: "#fff",
          borderBottom: "1px solid #e2e8f0",
          flexShrink: 0,
          flexWrap: "wrap",
        }}
      >
        <button
          onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
          disabled={currentPage === 1}
          style={{
            padding: "4px 8px",
            borderRadius: "6px",
            border: "1px solid #e2e8f0",
            background: "#f8fafc",
            cursor: "pointer",
            fontSize: "13px",
          }}
        >
          Prev
        </button>

        <span
          style={{
            fontSize: "12px",
            color: "#64748b",
            minWidth: "70px",
            textAlign: "center",
          }}
        >
          {currentPage} / {totalPages || 0}
        </span>

        <button
          onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
          disabled={currentPage === totalPages || totalPages === 0}
          style={{
            padding: "4px 8px",
            borderRadius: "6px",
            border: "1px solid #e2e8f0",
            background: "#f8fafc",
            cursor: "pointer",
            fontSize: "13px",
          }}
        >
          Next
        </button>

        <button
          onClick={() => setScale((s) => Number(Math.max(0.6, s - 0.2).toFixed(1)))}
          style={{
            padding: "4px 8px",
            borderRadius: "6px",
            border: "1px solid #e2e8f0",
            background: "#f8fafc",
            cursor: "pointer",
            fontSize: "13px",
          }}
        >
          -
        </button>

        <span
          style={{
            fontSize: "12px",
            color: "#64748b",
            minWidth: "38px",
            textAlign: "center",
          }}
        >
          {Math.round(scale * 100)}%
        </span>

        <button
          onClick={() => setScale((s) => Number(Math.min(3, s + 0.2).toFixed(1)))}
          style={{
            padding: "4px 8px",
            borderRadius: "6px",
            border: "1px solid #e2e8f0",
            background: "#f8fafc",
            cursor: "pointer",
            fontSize: "13px",
          }}
        >
          +
        </button>

        {activeField && (
          <div
            style={{
              marginLeft: "auto",
              display: "flex",
              alignItems: "center",
              gap: "6px",
              background:
                matchInfo.count > 0 ? "rgba(250,204,21,0.15)" : "rgba(100,116,139,0.1)",
              border:
                matchInfo.count > 0
                  ? "1px solid rgba(234,179,8,0.5)"
                  : "1px solid rgba(100,116,139,0.2)",
              borderRadius: "20px",
              padding: "3px 10px",
              fontSize: "11px",
              fontWeight: 500,
              color: matchInfo.count > 0 ? "#92400e" : "#475569",
            }}
          >
            {matchInfo.count > 0 ? (
              <span style={{ color: "#d97706" }}>
                {activeField} found on page {matchInfo.page}
              </span>
            ) : (
              <span>{activeField} searching...</span>
            )}
          </div>
        )}
      </div>

      <div
        style={{
          flex: 1,
          overflowY: "auto",
          overflowX: "auto",
          padding: "16px",
          background: "#e8ecf0",
        }}
      >
        <div
          ref={containerRef}
          style={{ boxShadow: "0 2px 12px rgba(0,0,0,0.15)" }}
        />
      </div>
    </div>
  );
}

// ── UTILS ─────────────────────────────────────────────────────────────────────
function highlight(json) {
  return json
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(
      /("(\\u[\da-fA-F]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g,
      (m) => {
        let cls = "jn";
        if (/^"/.test(m)) cls = /:$/.test(m) ? "jk" : "js";
        else if (/true|false/.test(m)) cls = "jb";
        else if (/null/.test(m)) cls = "jnu";
        return `<span class="${cls}">${m}</span>`;
      }
    );
}

let _idCounter = 0;
const nextId = () => ++_idCounter;

const getTemplateTheme = (name) => {
  const lower = String(name).toLowerCase();
  if (lower.includes('health')) return { 
    icon: <Activity size={18} strokeWidth={2} />, 
    bg: '#e0f2fe', color: '#3b82f6', tagBg: '#e0f2fe', tagColor: '#3b82f6' 
  };
  if (lower.includes('financ')) return { 
    icon: <DollarSign size={18} strokeWidth={2} />, 
    bg: '#dcfce7', color: '#22c55e', tagBg: '#dcfce7', tagColor: '#22c55e' 
  };
  if (lower.includes('msa')) return { 
    icon: <ShieldCheck size={18} strokeWidth={2} />, 
    bg: '#f3e8ff', color: '#a855f7', tagBg: '#f3e8ff', tagColor: '#a855f7' 
  };
  if (lower.includes('sow')) return { 
    icon: <FileText size={18} strokeWidth={2} />, 
    bg: '#fef3c7', color: '#f59e0b', tagBg: '#fef3c7', tagColor: '#f59e0b' 
  };
  return { 
    icon: <LayoutGrid size={18} strokeWidth={2} />, 
    bg: '#f1f5f9', color: '#64748b', tagBg: '#f1f5f9', tagColor: '#64748b' 
  };
};



// ── NEW EXTRACTION UI ──────────────────────────────────────────────────────────
function NewExtractionUI({
  files,
  dataPoints,
  setDataPoints,
  setPreset,
  newField,
  setNewField,
  newPrompt,
  setNewPrompt,
  dragging,
  expanded,
  result,
  view,
  setView,
  loading,
  prog,
  error,
  selectedPreset,
  preset,
  verifyMode,
  fileInputRef,
  resultSecRef,
  copiedJSON,
  withPrompts,
  missingCount,
  canRun,
  resultEntries,
  resultFilename,
  verifyEntries,
  approvedCount,
  flaggedCount,
  pendingCount,
  verifiedFields,
  editedResult,
  flagNotes,
  pdfUrls,
  activeFileIdx,
  setActiveFileIdx,
  activeFileName,
  resultFileNames,
  activeFileResult,
  summary,
  activeField,
  setActiveField,
  pdfSearchText,
  setPdfSearchText,
  onDragOver,
  onDragLeave,
  onDrop,
  onFileChange,
  clearFile,
  applyFile,
  addDataPoint,
  handlePresetChange,
  addPreset,
  removeDataPoint,
  updateDpField,
  updateDpPrompt,
  toggleExpand,
  runExtraction,
  copyJSON,
  downloadExcel,
  setFieldStatus,
  setFieldValue,
  setFieldNote,
  approveAll,
  saveJson,
  exportVerified,
  backToExtraction,
  setVerifyMode,
  setActiveNav,
  uploadSource,
  switchUploadSource,
  openDrivePicker,
  driveModalOpen,
  closeDrivePicker,
  driveSearch,
  setDriveSearch,
  driveLoading,
  driveError,
  driveConnected,
  filteredDriveFiles,
  importDriveFile,
  driveSelectingId,
  openOneDrivePicker,
  oneDriveModalOpen,
  closeOneDrivePicker,
  oneDriveSearch,
  setOneDriveSearch,
  oneDriveLoading,
  oneDriveError,
  oneDriveConnected,
  filteredOneDriveFiles,
  importOneDriveFile,
  oneDriveSelectingId,
}) {
  const [presetOpen, setPresetOpen] = useState(false);
  const selectRef = useRef(null);
  const [selectedPage, setSelectedPage] = useState(1);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (selectRef.current && !selectRef.current.contains(event.target)) {
        setPresetOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const theme = getTemplateTheme(preset || "Financial Statements");
  
  const presetsList = [
    { value: "Invoice Checking", label: "Invoice Checking" },
    { value: "Financial Statements", label: "Financial Statements" },
    { value: "Legal Documents", label: "Legal Documents" },
    { value: "Health Care Documents", label: "Health Care Documents" },
    { value: "MSA Extraction", label: "MSA Extraction" },
    { value: "SOW Extraction", label: "SOW Extraction" }
  ];

  return (
    <>
      {/* ══════════════════ VERIFY SCREEN ══════════════════ */}
      {verifyMode && result && (
        <div className="dv-root">
          {/* ── Top bar ── */}
          <div className="dv-topbar-v2">
            <div className="dv-topbar-left-v2">
              <button className="dv-breadcrumb-link" onClick={backToExtraction}>
                <ChevronDown size={14} style={{transform:'rotate(90deg)',marginRight:'4px'}}/> Extractions
              </button>
              <ChevronRight size={14} className="dv-breadcrumb-sep" />
              <div className="dv-breadcrumb-current">
                {activeFileName || "Review"}
              </div>
              <div className="dv-topbar-stats-v2">
                <span className="dv-stat-v2 approved">{approvedCount} Approved</span>
                <span className="dv-stat-v2 flagged">{flaggedCount} Flagged</span>
                <span className="dv-stat-v2 pending">{pendingCount} Pending</span>
              </div>
              {summary && (
                <span className="dv-stat-v2" style={{color:'var(--text-dim)',fontSize:'11px'}}>
                  {summary.total_files} file{summary.total_files !== 1 ? 's' : ''} · {summary.total_time}s
                </span>
              )}
            </div>
            <div className="dv-topbar-actions-v2">
              <button className="dv-approve-all-btn-v2" onClick={approveAll}>
                <Check size={14} strokeWidth={2.5} /> Approve All
              </button>
              <button className="dv-save-btn-v2" onClick={saveJson}>
                <Save size={14} strokeWidth={2} /> Save
              </button>
              <button className="dv-export-btn-v2" onClick={exportVerified}>
                <Download size={14} strokeWidth={2} /> Export Verified
              </button>
            </div>
          </div>

          {/* ── Body: PDF | file-tabs | fields ── */}
          <div className="dv-split-v2">

            {/* LEFT: PDF viewer */}
            <div className="dv-pdf-pane-v2" style={{padding:0,border:'none',overflow:'hidden'}}>
              <PdfHighlightViewer
                url={pdfUrls[activeFileName]}
                searchText={pdfSearchText}
                activeField={activeField?.name}
              />
            </div>

            {/* RIGHT: file tabs + fields panel */}
            <div className="dv-fields-pane-v2" style={{display:'flex',flexDirection:'column',padding:0,overflow:'hidden'}}>

              {/* File tabs — shown only when >1 file */}
              {resultFileNames.length > 1 && (
                <div className="dv-file-tabs">
                  {resultFileNames.map((fname, fi) => {
                    const fResult = result[fname];
                    const fieldKeys = Object.keys(fResult?.extracted_fields || {});
                    const fApproved = fieldKeys.filter(k => verifiedFields[`${fname}::${k}`] === "approved").length;
                    const fFlagged  = fieldKeys.filter(k => verifiedFields[`${fname}::${k}`] === "flagged").length;
                    const fPending  = fieldKeys.filter(k => (verifiedFields[`${fname}::${k}`] || "pending") === "pending").length;
                    const isFailed  = fResult?.file_status === "failed";
                    return (
                      <button
                        key={fname}
                        className={`dv-file-tab${fi === activeFileIdx ? " active" : ""}${isFailed ? " failed" : ""}`}
                        onClick={() => setActiveFileIdx(fi)}
                        title={fname}
                      >
                        <span className="dv-file-tab-name">{fname}</span>
                        <span className="dv-file-tab-meta">
                          {isFailed
                            ? <span style={{color:'#f87171',fontSize:'10px'}}>Failed</span>
                            : <>
                                <span style={{fontSize:'10px',color:'var(--text-dim)'}}>{fieldKeys.length} fields</span>
                                {fApproved > 0 && <span className="dv-dot dot-green" title={`${fApproved} approved`}/>}
                                {fFlagged  > 0 && <span className="dv-dot dot-amber" title={`${fFlagged} flagged`}/>}
                                {fPending  > 0 && <span className="dv-dot dot-gray"  title={`${fPending} pending`}/>}
                              </>
                          }
                        </span>
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Fields scroll area */}
              <div style={{flex:1,overflowY:'auto',padding:'16px'}}>
                {/* Panel header */}
                <div className="dv-pane-header-v2" style={{marginBottom:'14px'}}>
                  <div className="dv-pane-label-v2">
                    <CheckSquare size={16} color="#64748b"/> EXTRACTED FIELDS
                  </div>
                  <span className="dv-field-count-pill">{verifyEntries.length} FIELDS</span>
                </div>

                {/* Failed file banner */}
                {result[activeFileName]?.file_status === "failed" && (
                  <div style={{
                    background:'rgba(248,113,113,0.08)',border:'1px solid rgba(248,113,113,0.3)',
                    borderRadius:'10px',padding:'14px 16px',color:'#f87171',fontSize:'13px',marginBottom:'16px'
                  }}>
                    ⚠ Extraction failed for this file: {result[activeFileName]?.error || "Unknown error"}
                  </div>
                )}

                {/* Field cards */}
                <div className="dv-fields-cards-grid">
                  {verifyEntries.map(([sk, val], idx) => {
                    // sk = "filename::fieldName"
                    const fieldName = sk.split("::").slice(1).join("::");
                    const status    = verifiedFields[sk] || "pending";
                    const isNull    = val === "" && (result[activeFileName]?.extracted_fields?.[fieldName] == null);
                    const isFlagged = status === "flagged";
                    const isActive  = activeField?.key === sk;

                    const handleHighlight = () => {
                      if (isActive) {
                        // Toggle off
                        setActiveField(null);
                        setPdfSearchText("");
                      } else {
                        setActiveField({ key: sk, name: fieldName, value: val });
                        // Use first meaningful chunk of the value as search text
                        const searchVal = (val || "").trim();
                        // For arrays/JSON, extract the first plain string
                        let search = searchVal;
                        try {
                          const parsed = JSON.parse(searchVal);
                          if (Array.isArray(parsed)) search = String(parsed[0] || "");
                          else if (typeof parsed === "object") search = Object.values(parsed)[0] || "";
                        } catch (_) {}
                        setPdfSearchText(search.substring(0, 60));
                      }
                    };

                    return (
                      <div
                        key={sk}
                        className={`dv-field-card-v3 status-${status}${isActive ? " card-active-highlight" : ""}`}
                        style={isActive ? { outline:'2px solid rgba(234,179,8,0.8)', outlineOffset:'1px', background:'rgba(254,252,232,0.5)' } : {}}
                      >
                        {/* Card header */}
                        <div className="dv-card-header-v3">
                          <div className="dv-card-num-label">
                            <span className="dv-card-num">{String(idx + 1).padStart(2, "0")}</span>
                            <span className="dv-card-label">{fieldName}</span>
                          </div>
                          <div style={{ display:'flex', alignItems:'center', gap:'6px' }}>
                            {/* Highlight in PDF button */}
                            {!isNull && val && (
                              <button
                                onClick={handleHighlight}
                                title={isActive ? "Stop highlighting" : "Highlight in PDF"}
                                style={{
                                  padding:'2px 7px', borderRadius:'10px', fontSize:'10px', fontWeight:500,
                                  border: isActive ? '1px solid rgba(234,179,8,0.8)' : '1px solid #e2e8f0',
                                  background: isActive ? 'rgba(254,252,232,0.9)' : '#f8fafc',
                                  color: isActive ? '#92400e' : '#64748b',
                                  cursor:'pointer', display:'flex', alignItems:'center', gap:'3px',
                                  transition:'all 0.15s'
                                }}
                              >
                                <svg viewBox="0 0 24 24" fill={isActive ? "#d97706" : "none"} stroke={isActive ? "#d97706" : "currentColor"} width="9" height="9" strokeWidth="2.5">
                                  <circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>
                                </svg>
                                {isActive ? "Highlighting" : "Find in PDF"}
                              </button>
                            )}
                            <span className={`dv-card-badge badge-${status === "pending" && !isNull ? "extracted" : status}`}>
                              {status === "approved" && "✓ Approved"}
                              {status === "flagged"  && "⚑ Flagged"}
                              {status === "pending"  && !isNull && "✓ Extracted"}
                              {status === "pending"  && isNull  && "— Not Found"}
                            </span>
                          </div>
                        </div>

                        {/* Editable value */}
                        <div className="dv-card-body-v3">
                          <textarea
                            className={`dv-card-textarea${isNull && !val ? " null-val" : ""}`}
                            value={val}
                            onChange={(e) => setFieldValue(sk, e.target.value)}
                            rows={Math.min(5, Math.max(2, (val || "").split("\n").length + 1))}
                            placeholder={isNull ? "No value found in document" : ""}
                          />
                          {isFlagged && (
                            <input
                              className="dv-flag-note-input"
                              placeholder="Add a note about this issue…"
                              value={flagNotes[sk] || ""}
                              onChange={(e) => setFieldNote(sk, e.target.value)}
                              style={{marginTop:'8px'}}
                            />
                          )}
                        </div>

                        {/* Approve / Flag actions */}
                        <div className="dv-card-footer-v3">
                          <button
                            className={`dv-card-action-btn flag${isFlagged ? " active" : ""}`}
                            onClick={() => setFieldStatus(sk, isFlagged ? "pending" : "flagged")}
                          >
                            <svg viewBox="0 0 24 24" fill="currentColor" width="10" height="10">
                              <path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1v19h2v-7z"/>
                            </svg>
                            {isFlagged ? "Unflag" : "Flag"}
                          </button>
                          <button
                            className={`dv-card-action-btn approve${status === "approved" ? " active" : ""}`}
                            onClick={() => setFieldStatus(sk, status === "approved" ? "pending" : "approved")}
                          >
                            <Check size={11} strokeWidth={3}/>
                            {status === "approved" ? "Approved" : "Approve"}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <button className="dv-add-field-bottom-btn" onClick={backToExtraction}>
                  <Plus size={14} strokeWidth={2.5}/> Add Field
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════ NORMAL EXTRACTION SCREEN ══════════════════ */}
      {!verifyMode && (
        <div className="de-wrap">
          <div className="de-surface-2">
            {/* ── STEP 1: UPLOAD ── */}
            <div className="de-source-switcher">
              <button
                className={`de-source-tab${uploadSource === "local" ? " active" : ""}`}
                onClick={() => switchUploadSource("local")}
              >
                <span>Upload PDF</span>
              </button>
              <button
                className={`de-source-tab${uploadSource === "drive" ? " active" : ""}`}
                onClick={() => switchUploadSource("drive")}
              >
                <span>Google Drive</span>
              </button>
              <button
                className={`de-source-tab${uploadSource === "onedrive" ? " active" : ""}`}
                onClick={() => switchUploadSource("onedrive")}
              >
                <span>Microsoft OneDrive</span>
              </button>
            </div>

            {uploadSource === "local" && (
              <div
                className={`de-drop-zone${dragging ? " dragover" : ""}`}
                onDragOver={onDragOver}
                onDragLeave={onDragLeave}
                onDrop={onDrop}
                onClick={() => fileInputRef.current?.click()}
              >
                <input 
                  type="file" 
                  accept="application/pdf,image/*"
                  multiple   
                  ref={fileInputRef} 
                  onChange={onFileChange}
                  style={{ display: 'none' }} 
                  onClick={(e) => e.stopPropagation()} 
                />
                <div className="de-up-icon">
                  <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5">
                    <path
                      d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
                      stroke="currentColor"
                    />
                  </svg>
                </div>
                <div className="de-up-title">Drop PDFs here or click to browse</div>
                <div className="de-up-sub">
                  Accepts <b>.pdf</b> files · multiple files supported
                </div>

                {/* Multi-file list */}
                {files.length > 0 && (
                  <div className="de-multi-file-list" onClick={(e) => e.stopPropagation()}>
                    {files.map((f) => (
                      <div key={f.name} className="de-multi-file-item">
                        <svg className="de-file-info-font" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z" />
                          <polyline points="14 2 14 8 20 8" />
                        </svg>
                        <span className="de-file-info-font">{f.name}</span>
                        <span style={{color:"var(--text-dim)",fontSize:"11px"}}>({(f.size/1024/1024).toFixed(2)} MB)</span>
                        <span className="rm" onClick={() => clearFile(f.name)}>✕</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {uploadSource === "drive" && (
              <div className="de-drive-launch" onClick={openDrivePicker}>
                <div className="de-up-icon">
                  <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5">
                    <path d="M4 7.5A3.5 3.5 0 017.5 4H10l2 2h4.5A3.5 3.5 0 0120 9.5v7A3.5 3.5 0 0116.5 20h-9A3.5 3.5 0 014 16.5v-9z" stroke="currentColor" />
                  </svg>
                </div>
                <div className="de-up-title">Select PDFs from Google Drive</div>
                <div className="de-up-sub">
                  Click to browse your Drive files
                </div>
                <button className="de-drive-btn" type="button" onClick={(e) => { e.stopPropagation(); openDrivePicker(); }}>
                  Browse Drive files
                </button>
                {files.length > 0 && (
                  <div className="de-multi-file-list" onClick={(e) => e.stopPropagation()}>
                    {files.map((f) => (
                      <div key={f.name} className="de-multi-file-item">
                        <svg className="de-file-info-font" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                          <polyline points="14 2 14 8 20 8"/>
                        </svg>
                        <span className="de-file-info-font">{f.name}</span>
                        <span style={{color:"var(--text-dim)",fontSize:"11px"}}>({(f.size/1024/1024).toFixed(2)} MB)</span>
                        <span className="rm" onClick={() => clearFile(f.name)}>✕</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {uploadSource === "onedrive" && (
              <div className="de-drive-launch" onClick={openOneDrivePicker}>
                <div className="de-up-icon">
                  <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.5">
                    <path d="M19.35 10.04C18.67 6.59 15.64 4 12 4 9.11 4 6.6 5.64 5.35 8.04 2.34 8.36 0 10.91 0 14c0 3.31 2.69 6 6 6h13c2.76 0 5-2.24 5-5 0-2.64-2.05-4.78-4.65-4.96z" stroke="currentColor" />
                  </svg>
                </div>
                <div className="de-up-title">Select PDFs from Microsoft OneDrive</div>
                <div className="de-up-sub">
                  Click to browse your OneDrive files
                </div>
                <button className="de-drive-btn" type="button" onClick={(e) => { e.stopPropagation(); openOneDrivePicker(); }}>
                  Browse OneDrive files
                </button>
                {files.length > 0 && (
                  <div className="de-multi-file-list" onClick={(e) => e.stopPropagation()}>
                    {files.map((f) => (
                      <div key={f.name} className="de-multi-file-item">
                        <svg className="de-file-info-font" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                          <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
                          <polyline points="14 2 14 8 20 8"/>
                        </svg>
                        <span className="de-file-info-font">{f.name}</span>
                        <span style={{color:"var(--text-dim)",fontSize:"11px"}}>({(f.size/1024/1024).toFixed(2)} MB)</span>
                        <span className="rm" onClick={() => clearFile(f.name)}>✕</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* ── STEP 2: DATA POINTS ── */}
            <div className="de-card">
              <div className="de-step-hd mt8">
                <div className="de-step-hd-sub">
                  <div>
                    <div className="de-step-title">Define Data Points &amp; Prompts</div>
                    <div className="de-step-sub">Each field has its own extraction instruction</div>
                  </div>
                  <div style={{ display: 'flex', gap: '12px', alignItems: 'center' }}>
                    <div className="de-custom-select-container" ref={selectRef}>
                      <button 
                        className="de-custom-select-btn" 
                        onClick={() => setPresetOpen(!presetOpen)}
                      >
                        <span className="de-custom-select-icon" style={{ backgroundColor: theme.bg, color: theme.color }}>
                          {theme.icon}
                        </span>
                        <span>{preset || "Select template"}</span>
                        <ChevronDown size={14} className="de-custom-select-chevron" />
                      </button>
                      
                      {presetOpen && (
                        <div className="de-custom-select-dropdown">
                          {presetsList.map(p => {
                            const pTheme = getTemplateTheme(p.value);
                            return (
                              <button 
                                key={p.value}
                                className={`de-custom-select-option ${preset === p.value ? "selected" : ""}`}
                                onClick={() => {
                                  handlePresetChange({ target: { value: p.value } });
                                  setPresetOpen(false);
                                }}
                              >
                                <span className="de-custom-select-icon" style={{ backgroundColor: pTheme.bg, color: pTheme.color }}>
                                  {pTheme.icon}
                                </span>
                                <span>{p.label}</span>
                              </button>
                            );
                          })}
                        </div>
                      )}
                    </div>
                    <button className="de-add-field-btn-v2" onClick={() => addDataPoint()}>
                      <Plus size={14} strokeWidth={2.5} /> Add Field
                    </button>
                    <button
                      className={`de-extract-btn-v2${loading ? " loading" : ""}`}
                      onClick={runExtraction}
                      disabled={!canRun || loading}
                    >
                      <span className="de-btn-txt"><Play size={14} className="de-btn-icon" fill="currentColor" /> Run Extraction</span>
                      <span className="de-btn-spin" />
                    </button>
                  </div>
                </div>

              </div>
              <div className="de-card-surface">
                {/* Add row */}
                <div className="de-dp-add-labels">
                  <span>FIELD NAME <span style={{color: '#ef4444'}}>*</span></span>
                  <span>EXTRACTION PROMPT / INSTRUCTION <span style={{color: '#ef4444'}}>*</span></span>
                </div>
                <div className="de-dp-add-row">
                  <div className="de-input-wrapper">
                    <span className="de-input-icon" style={{ backgroundColor: '#c4d0e2', color: '#265cb3' }}>
                      <Type size={14} strokeWidth={2.5} />
                    </span>
                    <input
                      type="text"
                      className="de-dp-field-input with-icon"
                      placeholder="e.g. Policy Number"
                      autoComplete="off"
                      value={newField}
                      onChange={(e) => setNewField(e.target.value)}
                      onKeyDown={(e) => { if (e.key === "Enter") { e.preventDefault(); addDataPoint(); } }}
                    />
                  </div>
                  
                  <div className="de-input-wrapper flex-1">
                    <span className="de-input-icon" style={{ backgroundColor: '#c4d0e2', color: '#265cb3' }}>
                      <Wand2 size={14} strokeWidth={2.5} />
                    </span>
                    <textarea
                      className="de-dp-prompt-input with-icon"
                      rows={1}
                      placeholder='e.g. Extract only the policy number. Return in format "POL-XXXXXXXX". If not found return null.'
                      value={newPrompt}
                      onChange={(e) => setNewPrompt(e.target.value)}
                    />
                  </div>
                </div>

                {/* Data point list */}
                <div className="de-dp-list">
                  {dataPoints.length === 0 && (
                    <div className="de-dp-empty-state">
                      <div className="de-empty-icon-wrapper">
                        <div className="de-empty-circle">
                          <FilePlus2 size={24} color="#6366f1" />
                        </div>
                      </div>
                      <div className="de-empty-text-wrap">
                        <h3>No data points added yet</h3>
                        <p>Add a field name and its extraction instruction above.</p>
                      </div>
                    </div>
                  )}

                  {dataPoints.map((dp, i) => {
                    const hasPrompt = dp.prompt.trim().length > 0;
                    const isOpen = expanded[dp.id] ?? false;

                    return (
                      <div key={dp.id} className="de-dp-item">
                        <div className="de-dp-item-head">
                          <div className="de-dp-item-num">{String(i + 1).padStart(2, "0")}</div>
                          <div className="de-dp-item-name">
                            <input
                              value={dp.field}
                              placeholder="Field name"
                              onChange={(e) => updateDpField(dp.id, e.target.value)}
                              onKeyDown={(e) => { if (e.key === "Enter") e.preventDefault(); }}
                            />
                          </div>
                          <button
                            className={`de-dp-expand-btn${isOpen ? " open" : ""}`}
                            onClick={() => toggleExpand(dp.id)}
                          >
                            <span style={{ fontSize: "10px", letterSpacing: ".5px" }}>
                              {hasPrompt ? "PROMPT ✓" : "ADD PROMPT"}
                            </span>
                            <span className="de-arrow">▾</span>
                          </button>
                          <button
                            type="button"
                            className="de-dp-delete-btn"
                            onClick={(e) => { e.stopPropagation(); e.preventDefault(); removeDataPoint(dp.id); }}
                            title="Remove"
                          >
                            ✕
                          </button>
                        </div>

                        <div className={`de-dp-item-body${isOpen ? " open" : ""}`}>
                          <div className="de-dp-prompt-label">
                            <span className="pl-dot" /> Extraction Instruction
                          </div>
                          <textarea
                            className="de-dp-item-textarea"
                            placeholder="Describe exactly how to extract this field — format, fallback rules, where to look in the document, etc."
                            value={dp.prompt}
                            onChange={(e) => updateDpPrompt(dp.id, e.target.value)}
                          />
                          <div className="de-dp-prompt-status">
                            {hasPrompt ? (
                              <span className="de-pst-filled">✓ Prompt defined</span>
                            ) : (
                              <span className="de-pst-empty">⚠ No prompt — field will be sent without instruction</span>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Presets */}
                <div className="de-presets-row">
                  <span className="de-presets-label">QUICK ADD:</span>
                  {selectedPreset.map((p) => {
                    return (
                      <button
                        key={p.field}
                        className="de-preset-chip-v2"
                        onClick={() => addPreset(p.field, p.prompt)}
                      >
                        {p.label}
                      </button>
                    )
                  })}
                </div>

                {/* Summary bar */}
                <div className="de-summary-bar-v2">
                  <div className="de-sb-stat-v2">
                    <div className="de-sb-icon-wrap" style={{ backgroundColor: '#f3e8ff', color: '#8b5cf6' }}>
                      <LayoutGrid size={16} />
                    </div>
                    <div className="de-sb-text-col">
                      <span className="de-sb-label">Total Fields</span>
                      <span className="de-sb-value text-blue">{dataPoints.length}</span>
                    </div>
                  </div>
                  <div className="de-sb-sep-v2" />
                  <div className="de-sb-stat-v2">
                    <div className="de-sb-icon-wrap" style={{ backgroundColor: '#dcfce7', color: '#10b981' }}>
                      <MessageSquare size={16} />
                    </div>
                    <div className="de-sb-text-col">
                      <span className="de-sb-label">With Prompts</span>
                      <span className="de-sb-value text-green">{withPrompts}</span>
                    </div>
                  </div>
                  <div className="de-sb-sep-v2" />
                  <div className="de-sb-stat-v2">
                    <div className="de-sb-icon-wrap" style={{ backgroundColor: '#fee2e2', color: '#ef4444' }}>
                      <AlertCircle size={16} />
                    </div>
                    <div className="de-sb-text-col">
                      <span className="de-sb-label">Missing Prompts</span>
                      <span className="de-sb-value text-red">{missingCount}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>




            {/* ── RUN BAR ── */}
            <div className="de-run-bar">
              <div className="de-run-info">
                <div>
                  PDFs: <span className="rv">
                    {files.length === 0 ? "—" : files.length === 1 ? files[0].name : `${files.length} files selected`}
                  </span>
                </div>
                <div>
                  Fields: <span className="rv">{dataPoints.length}</span>
                  &nbsp;·&nbsp; Backend: <span className="rv">localhost:5000</span>
                </div>
              </div>
            </div>

            {/* ── PROGRESS ── */}
            <div className="de-prog-msg">{prog.msg}</div>
            <div className={`de-prog-wrap${prog.show ? " show" : ""}`}>
              <div className="de-prog-bar" style={{ width: prog.pct + "%" }} />
            </div>

            {/* ── ERROR ── */}
            {error && <div className="de-error-box show">⚠ {error}</div>}

            {/* ── RESULTS ── */}
            <div ref={resultSecRef} className={`de-results-section${result ? " show" : ""}`}>
              <div className="de-res-header">
                <div className="de-res-title-g">
                  <div className="de-res-dot" />
                  <span className="de-res-title">Extraction Results</span>
                  <span className="de-res-count">{resultEntries.length} fields</span>
                  {resultFileNames.length > 1 && (
                    <span style={{fontSize:'11px',color:'var(--text-dim)',fontFamily:'var(--font-mono)'}}>
                      · {resultFileNames.length} files
                    </span>
                  )}
                </div>
                <div style={{ display: "flex", gap: "10px", alignItems: "center", flexWrap: "wrap" }}>
                  <div className="de-vtoggle">
                    <button className={`de-vt${view === "table" ? " active" : ""}`} onClick={() => setView("table")}>Table</button>
                    <button className={`de-vt${view === "json"  ? " active" : ""}`} onClick={() => setView("json")}>JSON</button>
                  </div>
                  <div className="de-res-acts">
                    <button className="de-act-btn" onClick={() => setVerifyMode(true)}>↗ Review with PDF</button>
                    <button className="de-act-btn" onClick={downloadExcel}>↓ Download Excel</button>
                  </div>
                </div>
              </div>

              {/* Per-file tab strip when >1 file */}
              {resultFileNames.length > 1 && (
                <div className="de-result-file-tabs">
                  {resultFileNames.map((fname, fi) => {
                    const fStatus = result[fname]?.file_status;
                    return (
                      <button
                        key={fname}
                        className={`de-result-file-tab${fi === activeFileIdx ? " active" : ""}${fStatus === "failed" ? " failed" : ""}`}
                        onClick={() => setActiveFileIdx(fi)}
                        title={fname}
                      >
                        {fname}
                        {fStatus === "failed" && <span style={{marginLeft:'4px',color:'#f87171'}}>✕</span>}
                      </button>
                    );
                  })}
                </div>
              )}

              {/* Failed file message */}
              {result && activeFileResult?.file_status === "failed" && (
                <div style={{padding:'16px',color:'#f87171',fontSize:'13px',background:'rgba(248,113,113,0.06)',borderRadius:'8px',margin:'12px 0'}}>
                  ⚠ Extraction failed for <b>{activeFileName}</b>: {activeFileResult?.error || "Unknown error"}
                </div>
              )}

              {/* Table view */}
              {view === "table" && (
                <div style={{ overflowX: "auto", padding: "20px 0" }}>
                  <table style={{
                    width: "100%",
                    borderCollapse: "collapse",
                    fontSize: "14px",
                    fontFamily: "var(--font-mono)"
                  }}>
                    <thead>
                      <tr style={{ backgroundColor: "var(--bg-secondary)", borderBottom: "2px solid var(--border)" }}>
                        <th style={{ padding: "12px 16px", textAlign: "left", fontWeight: "600", color: "var(--text-primary)" }}>Field</th>
                        <th style={{ padding: "12px 16px", textAlign: "left", fontWeight: "600", color: "var(--text-primary)" }}>Value</th>
                      </tr>
                    </thead>
                    <tbody>
                      {resultEntries.map(([k, v], idx) => {
                        const isNull = v === null || v === undefined;
                        const cellValue = isNull ? "null" : typeof v === "object" ? JSON.stringify(v, null, 2) : String(v);
                        return (
                          <tr key={k} style={{ borderBottom: "1px solid var(--border)", backgroundColor: idx % 2 === 0 ? "transparent" : "rgba(255,255,255,0.02)" }}>
                            <td style={{ padding: "12px 16px", color: "var(--text-secondary)", fontWeight: "500", maxWidth: "300px", wordBreak: "break-word" }}>{k}</td>
                            <td style={{ padding: "12px 16px", color: isNull ? "var(--text-dim)" : "var(--text-primary)", maxWidth: "500px", whiteSpace: "pre-wrap", wordBreak: "break-word" }}>{cellValue}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}

              {/* JSON view */}
              {view === "json" && (
                <div className="de-json-viewer">
                  <div className="de-jvt">
                    <div className="de-jv-dots">
                      <div className="de-jv-dot" />
                      <div className="de-jv-dot" />
                      <div className="de-jv-dot" />
                    </div>
                    <span className="de-jv-fn">{resultFilename}</span>
                    <span />
                  </div>
                  <pre
                    className="de-json-pre"
                    dangerouslySetInnerHTML={{
                      __html: result ? highlight(JSON.stringify(result, null, 2)) : "",
                    }}
                  />
                </div>
              )}
            </div>
          </div>

          {driveModalOpen && (
            <div className="de-drive-modal-backdrop" onClick={closeDrivePicker}>
              <div className="de-drive-modal" onClick={(e) => e.stopPropagation()}>
                <div className="de-drive-modal-head">
                  <div>
                    <div className="de-drive-modal-title">Select from Google Drive</div>
                    <div className="de-drive-modal-sub">Choose a PDF document to extract</div>
                  </div>
                  <button className="de-drive-modal-close" onClick={closeDrivePicker} aria-label="Close">
                    ×
                  </button>
                </div>

                <div className="de-drive-modal-search">
                  <input
                    type="text"
                    value={driveSearch}
                    onChange={(e) => setDriveSearch(e.target.value)}
                    placeholder="Search files..."
                  />
                </div>

                <div className="de-drive-modal-body">
                  {driveLoading ? (
                    <div className="de-drive-state">
                      <div className="spinner" />
                      Loading Drive files…
                    </div>
                  ) : driveError ? (
                    <div className="de-drive-state de-drive-state-error">
                      <div>
                        {driveError.includes("insufficient") || driveError.includes("scope")
                          ? "Access to Google Drive was not fully authorized. Please go to Integrations, disconnect Google Drive, and reconnect it, ensuring you check the checkbox to view and download your files."
                          : driveError}
                      </div>
                      <button
                        className="de-drive-modal-action"
                        onClick={() => {
                          closeDrivePicker();
                          setActiveNav("integrations");
                        }}
                      >
                        Go to Integrations
                      </button>
                    </div>
                  ) : filteredDriveFiles.length === 0 ? (
                    <div className="de-drive-state">No PDF files found.</div>
                  ) : (
                    filteredDriveFiles.map((item) => (
                      <button
                        key={item.id}
                        className="de-drive-file-row"
                        onClick={() => importDriveFile(item)}
                        disabled={driveSelectingId !== null}
                      >
                        <div className="de-drive-file-icon">PDF</div>
                        <div className="de-drive-file-meta">
                          <span className="de-drive-file-name">{item.name}</span>
                          <span className="de-drive-file-id">{item.id}</span>
                        </div>
                        <span className="de-drive-file-action">
                          {driveSelectingId === item.id ? "Loading…" : "Select"}
                        </span>
                      </button>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {oneDriveModalOpen && (
            <div className="de-drive-modal-backdrop" onClick={closeOneDrivePicker}>
              <div className="de-drive-modal" onClick={(e) => e.stopPropagation()}>
                <div className="de-drive-modal-head">
                  <div>
                    <div className="de-drive-modal-title">Select from Microsoft OneDrive</div>
                    <div className="de-drive-modal-sub">Choose a PDF document to extract</div>
                  </div>
                  <button className="de-drive-modal-close" onClick={closeOneDrivePicker} aria-label="Close">
                    ×
                  </button>
                </div>

                <div className="de-drive-modal-search">
                  <input
                    type="text"
                    value={oneDriveSearch}
                    onChange={(e) => setOneDriveSearch(e.target.value)}
                    placeholder="Search files..."
                  />
                </div>

                <div className="de-drive-modal-body">
                  {oneDriveLoading ? (
                    <div className="de-drive-state">
                      <div className="spinner" />
                      Loading OneDrive files…
                    </div>
                  ) : oneDriveError ? (
                    <div className="de-drive-state de-drive-state-error">
                      <div>
                        {oneDriveError.includes("insufficient") || oneDriveError.includes("scope")
                          ? "Access to Microsoft OneDrive was not fully authorized. Please go to Integrations, disconnect OneDrive, and reconnect it, ensuring you grant access to view and download your files."
                          : oneDriveError}
                      </div>
                      <button
                        className="de-drive-modal-action"
                        onClick={() => {
                          closeOneDrivePicker();
                          setActiveNav("integrations");
                        }}
                      >
                        Go to Integrations
                      </button>
                    </div>
                  ) : filteredOneDriveFiles.length === 0 ? (
                    <div className="de-drive-state">No PDF files found.</div>
                  ) : (
                    filteredOneDriveFiles.map((item) => (
                      <button
                        key={item.id}
                        className="de-drive-file-row"
                        onClick={() => importOneDriveFile(item)}
                        disabled={oneDriveSelectingId !== null}
                      >
                        <div className="de-drive-file-icon">PDF</div>
                        <div className="de-drive-file-meta">
                          <span className="de-drive-file-name">{item.name}</span>
                          <span className="de-drive-file-id">{item.id}</span>
                        </div>
                        <span className="de-drive-file-action">
                          {oneDriveSelectingId === item.id ? "Loading…" : "Select"}
                        </span>
                      </button>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </>
  );
}

function SettingsPage({ activeTab, setActiveTab, notifications, setNotifications }) {
  const [userEmail, setUserEmail] = useState("");
  const [newEmailInput, setNewEmailInput] = useState("");
  const [otpSent, setOtpSent] = useState(false);
  const [otpDigits, setOtpDigits] = useState(["", "", "", "", "", ""]);
  const [generatedOtp, setGeneratedOtp] = useState("");
  const [emailError, setEmailError] = useState("");
  const [emailSuccess, setEmailSuccess] = useState("");
  useEffect(() => {
    setUserEmail(localStorage.getItem("email") || "");
  }, []);

  // Password change states
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [passwordSuccess, setPasswordSuccess] = useState("");
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Notification states
  const [notifSuccess, setNotifSuccess] = useState(true);
  const [notifFailure, setNotifFailure] = useState(true);
  const [notifReview, setNotifReview] = useState(true);
  const [notifDigest, setNotifDigest] = useState(false);
  const [notifUsage, setNotifUsage] = useState(true);
  const [notifEmail, setNotifEmail] = useState(true);
  const [notifInApp, setNotifInApp] = useState(true);
  const [notifSlack, setNotifSlack] = useState(false);
  const [notifSuccessBanner, setNotifSuccessBanner] = useState("");

  const handleSaveNotifications = (e) => {
    e.preventDefault();
    setNotifSuccessBanner("Notification preferences updated successfully.");
    setTimeout(() => {
      setNotifSuccessBanner("");
    }, 4000);
  };

  const getPasswordStrength = (pwd) => {
    if (!pwd) return { score: 0, label: "Empty", color: "#e2e8f0" };
    let score = 0;
    if (pwd.length >= 8) score += 1;
    if (/[A-Z]/.test(pwd)) score += 1;
    if (/[0-9]/.test(pwd)) score += 1;
    if (/[^A-Za-z0-9]/.test(pwd)) score += 1;
    
    if (score <= 1) return { score: 25, label: "Weak", color: "#ef4444" };
    if (score === 2) return { score: 50, label: "Fair", color: "#f59e0b" };
    if (score === 3) return { score: 75, label: "Good", color: "#3b82f6" };
    return { score: 100, label: "Strong", color: "#10b981" };
  };

  const handleUpdatePassword = async (e) => {
    e.preventDefault();
    setPasswordError("");
    setPasswordSuccess("");

    if (!currentPassword) {
      setPasswordError("Please enter your current password.");
      return;
    }
    if (!newPassword) {
      setPasswordError("Please enter a new password.");
      return;
    }
    if (newPassword.length < 8) {
      setPasswordError("New password must be at least 8 characters long.");
      return;
    }
    if (newPassword === currentPassword) {
      setPasswordError("New password cannot be the same as your current password.");
      return;
    }
    if (newPassword !== confirmPassword) {
      setPasswordError("Passwords do not match. Please verify the confirmation password.");
      return;
    }

    // Successfully updated (mock)
const response = await fetch(`${BACKEND_URL}/change_password`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        "user_id" : localStorage.getItem("id"),
        "current_password" : currentPassword,
        "new_password" : newPassword,
      }),
    });
    if (response.ok) {
      setPasswordError("");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      let message = await response.json();
      setPasswordSuccess(message.message);
    } else {
      let error = await response.json();
      setPasswordError(error.message);
      }
  };

  const otpInputRefs = [
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null),
    useRef(null)
  ];

  const handleOtpChange = (index, value) => {
    if (value && !/^\d$/.test(value)) return;
    const newDigits = [...otpDigits];
    newDigits[index] = value;
    setOtpDigits(newDigits);
    if (value && index < 5) {
      otpInputRefs[index + 1].current.focus();
    }
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otpDigits[index] && index > 0) {
      otpInputRefs[index - 1].current.focus();
    }
  };

  const handleOtpPaste = (e) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").trim();
    if (/^\d{6}$/.test(pastedData)) {
      const newDigits = pastedData.split("");
      setOtpDigits(newDigits);
      if (otpInputRefs[5].current) {
        otpInputRefs[5].current.focus();
      }
    }
  };

  const handleSendOtp = async () => {
    setEmailError("");
    setEmailSuccess("");
    
    if (!newEmailInput) {
      setEmailError("Please enter a new email address.");
      return;
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(newEmailInput)) {
      setEmailError("Please enter a valid email address.");
      return;
    }
    
    if (newEmailInput.toLowerCase() === userEmail.toLowerCase()) {
      setEmailError("New email must be different from current email.");
      return;
    }
    
    const response = await fetch(`${BACKEND_URL}/send_otp`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        "user_id": localStorage.getItem("id"),
        "email": userEmail.toLowerCase(),
      }),
    });
    if (response.ok) {
      const data = await response.json();
      setEmailSuccess(data.message);
    } else {
      const errorData = await response.json();
      setEmailError(errorData.error || "Failed to send verification code. Please try again.");
    };
    setOtpSent(true);
  };

  const handleVerifyOtp = async () => {
    setEmailError("");
    setEmailSuccess("");
    const enteredOtp = otpDigits.join("");
    
    if (enteredOtp.length < 6) {
      setEmailError("Please enter all 6 digits of the verification code.");
      return;
    }
    
    const response = await fetch(`${BACKEND_URL}/change_email/verify_otp`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        "user_id": localStorage.getItem("id"),
        "email": userEmail.toLowerCase(),
        "new_email": newEmailInput.toLowerCase(),
        "otp": enteredOtp,
      }),
    });
    if (response.ok) {
      const data = await response.json();
      setUserEmail(newEmailInput.toLowerCase());
      localStorage.setItem("email", newEmailInput.toLowerCase());
      setEmailSuccess(data.message);
    } else {
      const errorData = await response.json();
      setEmailError(errorData.error || "Invalid verification code. Please try again.");
    }
    
  };

  const handleCancelEmailChange = () => {
    setOtpSent(false);
    setGeneratedOtp("");
    setOtpDigits(["", "", "", "", "", ""]);
    setNewEmailInput("");
    setEmailError("");
    setEmailSuccess("");
  };
  const [contactMode, setContactMode] = useState("existing");
  const [additionalEmail, setAdditionalEmail] = useState("");
  const [showExtraCard, setShowExtraCard] = useState(false);
  const [primaryCard, setPrimaryCard] = useState({
    name: "Alex Johnson",
    expiry: "02/2028",
    number: "8269962092922538",
    cvv: "123",
  });
  const [extraCard, setExtraCard] = useState({
    name: "",
    expiry: "",
    number: "",
    cvv: "",
  });

  const [primaryCardFocused, setPrimaryCardFocused] = useState(false);
  const [extraCardFocused, setExtraCardFocused] = useState(false);
  const [primaryCvvFocused, setPrimaryCvvFocused] = useState(false);
  const [extraCvvFocused, setExtraCvvFocused] = useState(false);

  const [showPrimaryNumber, setShowPrimaryNumber] = useState(false);
  const [showPrimaryCvv, setShowPrimaryCvv] = useState(false);
  const [showExtraNumber, setShowExtraNumber] = useState(false);
  const [showExtraCvv, setShowExtraCvv] = useState(false);

  const formatExpiry = (val) => {
    const clean = val.replace(/\D/g, "");
    if (clean.length <= 2) return clean;
    return `${clean.slice(0, 2)}/${clean.slice(2, 6)}`;
  };

  const getCardValue = (val, isFocused, isVisible) => {
    const clean = val.replace(/\D/g, "").slice(0, 16);
    if (isFocused || isVisible) {
      return clean.replace(/(\d{4})/g, '$1 ').trim();
    } else {
      if (clean.length < 4) return clean;
      const last4 = clean.slice(-4);
      return `•••• •••• •••• ${last4}`;
    }
  };

  const getCvvValue = (val, isFocused, isVisible) => {
    const clean = val.replace(/\D/g, "").slice(0, 3);
    if (isFocused || isVisible) {
      return clean;
    } else {
      return "•".repeat(clean.length);
    }
  };

  const billingRows = [
    { invoice: "DocExtract Pro", date: "Apr 14, 2026", amount: "$299", status: "Paid", tracking: "INV-2026-0414" },
    { invoice: "Extractions Add-on", date: "Apr 10, 2026", amount: "$89", status: "Pending", tracking: "INV-2026-0410" },
    { invoice: "Storage Add-on", date: "Mar 28, 2026", amount: "$40", status: "Paid", tracking: "INV-2026-0328" },
  ];

  const renderSimpleCard = (icon, title, sub, actionLabel = "Update") => {
    const Icon = icon;
    return (
      <div className="settings-profile-card">
        <div className="settings-card-title">
          <Icon size={16} />
          <span>{title}</span>
        </div>
        <p style={{ color: "#8d93a8", fontSize: "13px", marginBottom: "14px" }}>{sub}</p>
        <button className="settings-primary-btn">{actionLabel}</button>
      </div>
    );
  };

  const updatePrimaryCard = (field, value) => {
    setPrimaryCard((prev) => ({ ...prev, [field]: value }));
  };

  const updateExtraCard = (field, value) => {
    setExtraCard((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="settings-shell">
      <div className="settings-wrap">
        <div className="settings-head">
          <h1>Settings</h1>
          <p>Manage your account settings and preferences.</p>
        </div>

        <div className="settings-tabs">
          {["Password", "Billings", "Subscription", "Email", "Notifications", "Notification Preferences"].map((tab) => (
            <button
              key={tab}
              className={`settings-tab${tab === activeTab ? " active" : ""}`}
              onClick={() => setActiveTab(tab)}
            >
              {tab}
            </button>
          ))}
        </div>

        <div className="settings-main-card">
          {activeTab === "Billings" ? (
            <BillingSettings/>
          ) : activeTab === "Notifications" ? (
            <div className="notifications-tab-container">
              {/* Recent Notifications Section */}
              <div className="notification-list-card">
                <div className="notification-settings-head">
                  <h2>
                    <Bell size={16} />
                    <span>Recent Notifications</span>
                  </h2>
                  <p>View and manage your recent account and document notifications.</p>
                </div>

                <div className="notifications-list-wrapper">
                  {notifications.length === 0 ? (
                    <div className="no-notifications-state">
                      <Bell size={24} style={{ color: '#cbd5e1', marginBottom: '8px' }} />
                      <p>You have no recent notifications.</p>
                    </div>
                  ) : (
                    <div className="notifications-items-list">
                      {notifications.map((notif) => {
                        const notifIcons = {
                          success: <CheckCircle size={15} className="notif-icon-svg success" />,
                          warning: <AlertTriangle size={15} className="notif-icon-svg warning" />,
                          info: <Info size={15} className="notif-icon-svg info" />
                        };
                        return (
                          <div key={notif.id} className={`notification-item-row ${notif.unread ? 'unread' : ''}`}>
                            <div className={`notif-icon-badge ${notif.type}`}>
                              {notifIcons[notif.type] || <Bell size={15} className="notif-icon-svg" />}
                            </div>
                            <div className="notif-content">
                              <div className="notif-header">
                                <span className="notif-title">{notif.title}</span>
                                <div className="notif-meta">
                                  <Clock size={11} className="notif-meta-clock" />
                                  <span className="notif-time">{notif.time}</span>
                                </div>
                              </div>
                              <p className="notif-desc">{notif.description}</p>
                            </div>
                            {notif.unread && (
                              <button
                                type="button"
                                className="mark-read-btn"
                                onClick={() => {
                                  setNotifications(prev => prev.map(n => n.id === notif.id ? { ...n, unread: false } : n));
                                }}
                                title="Mark as read"
                                aria-label="Mark as read"
                              >
                                <Check size={14} />
                              </button>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                  {notifications.some(n => n.unread) && (
                    <button
                      type="button"
                      className="mark-all-read-btn"
                      onClick={() => setNotifications(prev => prev.map(n => ({ ...n, unread: false })))}
                    >
                      Mark all as read
                    </button>
                  )}
                </div>
              </div>
            </div>
          ) : activeTab === "Notification Preferences" ? (
            <div className="notifications-tab-container">
              {/* Notification Preferences Section */}
              <div className="notification-settings-card">
                <div className="notification-settings-head">
                  <h2>
                    <Bell size={16} />
                    <span>Notification Preferences</span>
                  </h2>
                  <p>Choose how and when you want to receive alerts and notifications.</p>
                </div>

                {notifSuccessBanner && (
                  <div className="email-status-banner success" style={{ marginBottom: '20px' }}>
                    <Check size={14} />
                    <span>{notifSuccessBanner}</span>
                  </div>
                )}

                <form onSubmit={handleSaveNotifications}>
                  <div className="notification-group">
                    <h3>Activity Alerts</h3>
                    <div className="notification-options">
                      <label className="notification-option-row">
                        <input
                          type="checkbox"
                          checked={notifSuccess}
                          onChange={() => setNotifSuccess(!notifSuccess)}
                        />
                        <div className="option-text">
                          <span className="option-title">Extraction Success</span>
                          <span className="option-desc">Receive an alert when a document is processed and parsed successfully.</span>
                        </div>
                      </label>

                      <label className="notification-option-row">
                        <input
                          type="checkbox"
                          checked={notifFailure}
                          onChange={() => setNotifFailure(!notifFailure)}
                        />
                        <div className="option-text">
                          <span className="option-title">Extraction Failure</span>
                          <span className="option-desc">Receive an alert if a document fails to parse or encounters an error.</span>
                        </div>
                      </label>

                      <label className="notification-option-row">
                        <input
                          type="checkbox"
                          checked={notifReview}
                          onChange={() => setNotifReview(!notifReview)}
                        />
                        <div className="option-text">
                          <span className="option-title">Flagged for Review</span>
                          <span className="option-desc">Receive an alert when an extraction contains fields flagged for manual verification.</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  <div className="notification-group">
                    <h3>Usage & Reports</h3>
                    <div className="notification-options">
                      <label className="notification-option-row">
                        <input
                          type="checkbox"
                          checked={notifDigest}
                          onChange={() => setNotifDigest(!notifDigest)}
                        />
                        <div className="option-text">
                          <span className="option-title">Weekly Summary Digest</span>
                          <span className="option-desc">Get a weekly email report of your extraction statistics, templates used, and savings.</span>
                        </div>
                      </label>

                      <label className="notification-option-row">
                        <input
                          type="checkbox"
                          checked={notifUsage}
                          onChange={() => setNotifUsage(!notifUsage)}
                        />
                        <div className="option-text">
                          <span className="option-title">Usage Limit Warning</span>
                          <span className="option-desc">Notify when your monthly extraction count reaches 80% and 100% of your plan limit.</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  <div className="notification-group">
                    <h3>Notification Channels</h3>
                    <div className="notification-options">
                      <label className="notification-option-row">
                        <input
                          type="checkbox"
                          checked={notifEmail}
                          onChange={() => setNotifEmail(!notifEmail)}
                        />
                        <div className="option-text">
                          <span className="option-title">Email Notifications</span>
                          <span className="option-desc">Send alert notifications directly to your primary email address.</span>
                        </div>
                      </label>

                      <label className="notification-option-row">
                        <input
                          type="checkbox"
                          checked={notifInApp}
                          onChange={() => setNotifInApp(!notifInApp)}
                        />
                        <div className="option-text">
                          <span className="option-title">In-App Notifications</span>
                          <span className="option-desc">Show notification badges and messages inside the platform dashboard.</span>
                        </div>
                      </label>

                      <label className="notification-option-row">
                        <input
                          type="checkbox"
                          checked={notifSlack}
                          onChange={() => setNotifSlack(!notifSlack)}
                        />
                        <div className="option-text">
                          <span className="option-title">Slack Integration Alerts</span>
                          <span className="option-desc">Push alerts directly to your connected team Slack channel.</span>
                        </div>
                      </label>
                    </div>
                  </div>

                  <div className="email-action-row" style={{ marginTop: '24px' }}>
                    <button type="submit" className="email-btn primary">
                      Save Notification Preferences
                    </button>
                  </div>
                </form>
              </div>
            </div>
          ) : activeTab === "Password" ? (
            <div className="password-settings-card">
              <div className="password-settings-head">
                <h2>
                  <Shield size={16} />
                  <span>Password Settings</span>
                </h2>
                <p>Update your account password and verify its strength.</p>
              </div>

              <form className="password-settings-form" onSubmit={handleUpdatePassword}>
                {passwordSuccess && (
                  <div className="email-status-banner success" style={{ marginBottom: '16px' }}>
                    <Check size={14} />
                    <span>{passwordSuccess}</span>
                  </div>
                )}

                {passwordError && (
                  <div className="email-status-banner error" style={{ marginBottom: '16px' }}>
                    <AlertCircle size={14} />
                    <span>{passwordError}</span>
                  </div>
                )}

                <div className="password-field">
                  <label htmlFor="current-password-input">Current Password</label>
                  <div className="settings-input-wrapper">
                    <input
                      id="current-password-input"
                      type={showCurrentPassword ? "text" : "password"}
                      className="password-input-field"
                      placeholder="Enter current password"
                      value={currentPassword}
                      onChange={(e) => setCurrentPassword(e.target.value)}
                    />
                    <button
                      type="button"
                      className="settings-input-toggle-btn"
                      onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                      title={showCurrentPassword ? "Hide password" : "Show password"}
                    >
                      {showCurrentPassword ? <Eye size={16} /> : <EyeOff size={16} />}
                    </button>
                  </div>
                </div>

                <div className="password-field">
                  <label htmlFor="new-password-input">New Password</label>
                  <div className="settings-input-wrapper">
                    <input
                      id="new-password-input"
                      type={showNewPassword ? "text" : "password"}
                      className="password-input-field"
                      placeholder="Enter new password (min. 8 characters)"
                      value={newPassword}
                      onChange={(e) => setNewPassword(e.target.value)}
                    />
                    <button
                      type="button"
                      className="settings-input-toggle-btn"
                      onClick={() => setShowNewPassword(!showNewPassword)}
                      title={showNewPassword ? "Hide password" : "Show password"}
                    >
                      {showNewPassword ? <Eye size={16} /> : <EyeOff size={16} />}
                    </button>
                  </div>

                  {newPassword && (
                    <div className="password-strength-container" style={{ animation: 'fadeIn 0.2s ease', marginTop: '8px' }}>
                      <div className="password-strength-bar-bg" style={{ height: '6px', background: '#f1f5f9', borderRadius: '3px', overflow: 'hidden', marginBottom: '6px' }}>
                        <div
                          className="password-strength-bar-fill"
                          style={{
                            height: '100%',
                            transition: 'width 0.3s ease, background-color 0.3s ease',
                            width: `${getPasswordStrength(newPassword).score}%`,
                            backgroundColor: getPasswordStrength(newPassword).color
                          }}
                        />
                      </div>
                      <span className="password-strength-text" style={{ fontSize: '12px', color: '#64748b' }}>
                        Password Strength: <strong style={{ color: getPasswordStrength(newPassword).color }}>{getPasswordStrength(newPassword).label}</strong>
                      </span>
                    </div>
                  )}
                </div>

                <div className="password-field">
                  <label htmlFor="confirm-password-input">Confirm New Password</label>
                  <div className="settings-input-wrapper">
                    <input
                      id="confirm-password-input"
                      type={showConfirmPassword ? "text" : "password"}
                      className="password-input-field"
                      placeholder="Verify new password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                    />
                    <button
                      type="button"
                      className="settings-input-toggle-btn"
                      onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                      title={showConfirmPassword ? "Hide password" : "Show password"}
                    >
                      {showConfirmPassword ? <Eye size={16} /> : <EyeOff size={16} />}
                    </button>
                  </div>
                </div>

                <div className="email-action-row" style={{ marginTop: '12px' }}>
                  <button type="submit" className="email-btn primary">
                    Update Password
                  </button>
                </div>
              </form>
            </div>
          ) : activeTab === "Email" ? (
            <div className="email-settings-card">
              <div className="email-settings-head">
                <h2>
                  <Mail size={16} />
                  <span>Email Settings</span>
                </h2>
                <p>Update your account email address with secure OTP verification.</p>
              </div>

              <div className="email-settings-grid">
                <div className="email-settings-field">
                  <label>Current Email Address</label>
                  <div className="email-current-box">
                    <span>{userEmail}</span>
                    <span style={{ fontSize: '11px', color: '#10b981', background: '#d1fae5', padding: '2px 8px', borderRadius: '12px', fontWeight: 600 }}>Verified</span>
                  </div>
                </div>

                {emailSuccess && (
                  <div className="email-status-banner success">
                    <Check size={14} />
                    <span>{emailSuccess}</span>
                  </div>
                )}

                {emailError && (
                  <div className="email-status-banner error">
                    <AlertCircle size={14} />
                    <span>{emailError}</span>
                  </div>
                )}

                {!otpSent ? (
                  <div className="email-settings-field">
                    <label htmlFor="new-email-input">New Email Address</label>
                    <div className="email-input-wrapper">
                      <input
                        id="new-email-input"
                        type="email"
                        className="email-input-field"
                        placeholder="Enter new email address (e.g. alex@company.com)"
                        value={newEmailInput}
                        onChange={(e) => setNewEmailInput(e.target.value)}
                      />
                    </div>
                    <div className="email-action-row" style={{ marginTop: '8px' }}>
                      <button className="email-btn primary" onClick={handleSendOtp}>
                        Send Verification OTP
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="email-settings-field" style={{ animation: 'fadeIn 0.3s ease' }}>
                    <label style={{ textAlign: 'center', display: 'block', marginBottom: '8px' }}>
                      Enter the 6-digit verification code sent to <strong>{userEmail}</strong>
                    </label>

                    <div className="otp-inputs-row">
                      {otpDigits.map((digit, idx) => (
                        <input
                          key={idx}
                          ref={otpInputRefs[idx]}
                          type="text"
                          maxLength={1}
                          className="otp-digit-input"
                          value={digit}
                          onChange={(e) => handleOtpChange(idx, e.target.value)}
                          onKeyDown={(e) => handleOtpKeyDown(idx, e)}
                          onPaste={handleOtpPaste}
                          aria-label={`Digit ${idx + 1}`}
                        />
                      ))}
                    </div>

                    <div className="email-action-row" style={{ justifyContent: 'center' }}>
                      <button className="email-btn secondary" onClick={handleCancelEmailChange}>
                        Cancel
                      </button>
                      <button className="email-btn primary" onClick={handleVerifyOtp}>
                        Verify & Update Email
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : activeTab === "Subscription" ? (
            <div className="pricing-section">
              <div className="pricing-badge">
                <DollarSign size={13} />
                <span>Our Pricing Plan</span>
              </div>
              <h2 className="pricing-title">Get started for free</h2>

              <div className="subscriptions-container">
                {/* Starter Plan */}
                <div className="subscription-card">
                  <div className="subscription-card-head">
                    <h3>Starter</h3>
                    <p>Your document extraction partner. Unlock instant, world-class parsing with a simple monthly plan.</p>
                    <div className="subscription-card-price">Free Plan</div>
                  </div>
                  <button className="subscription-card-btn btn-starter" style={{ background: '#e2e8f0', color: '#64748b', cursor: 'default' }} disabled>
                    <Check size={14} />
                    <span>Using Plan</span>
                  </button>
                  <div className="subscription-features-title">GET STARTED WITH</div>
                  <ul className="subscription-features-list">
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>1,000 free extractions</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Speak ai Engine</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>5 Custom Template fields</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>10 Language models supported</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Document export tools</span>
                    </li>
                  </ul>
                </div>

                {/* Pro Plan */}
                <div className="subscription-card">
                  <div className="subscription-card-head">
                    <h3>Pro Plan</h3>
                    <p>Your advanced document partner. Unlock instant, world-class extraction with a simple monthly fee.</p>
                    <div className="subscription-card-price">$8.00 <span>/Month</span></div>
                  </div>
                  <button className="subscription-card-btn btn-pro" onClick={() => setActiveTab("Billings")}>
                    <span>Get Pro Plan</span>
                  </button>
                  <div className="subscription-features-title">EVERYTHING IN STARTER</div>
                  <ul className="subscription-features-list">
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Unlimited extractions</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Advanced AI parser</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Avalon model support</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>800 Custom Template fields</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Tune with custom prompts</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>API access integration</span>
                    </li>
                  </ul>
                </div>

                {/* Team Plan */}
                <div className="subscription-card">
                  <div className="subscription-card-head">
                    <h3>Team Plan</h3>
                    <p>Your team processing partner. Unlock instant, world-class workflow with a simple monthly fee.</p>
                    <div className="subscription-card-price">$12.00 <span>/Month</span></div>
                  </div>
                  <button className="subscription-card-btn btn-team" onClick={() => setActiveTab("Billings")}>
                    <span>Get Team Plan</span>
                    <ChevronRight size={14} />
                  </button>
                  <div className="subscription-features-title">EVERYTHING IN PRO</div>
                  <ul className="subscription-features-list">
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Avalon model support</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Centralized team billing</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Team wide settings</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Enforce privacy mode org-wide</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Priority support</span>
                    </li>
                    <li className="subscription-feature-item">
                      <Check size={14} />
                      <span>Advanced Analytics Dashboard</span>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          ) : (
            renderSimpleCard(KeyRound, "API Keys", "Manage API access tokens for integrations.", "Manage API Keys")
          )}
        </div>
      </div>
    </div>
  );
}

function TemplateEditor({ templateId, onBack, onUseTemplate, initialTab = "overview" }) {
  const [template, setTemplate] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState("");
  const [editContent, setEditContent] = useState("");
  const [editDataPoints, setEditDataPoints] = useState([]);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState(initialTab); // "overview" | "datapoints"
  const [newField, setNewField] = useState("");
  const [newPrompt, setNewPrompt] = useState("");

  useEffect(() => {
    let isMounted = true;
    const fetchTemplate = async () => {
      if (templateId === 'new') {
        setTemplate({ template_name: "", template_content: "", data_points: [] });
        setEditName("");
        setEditContent("");
        setEditDataPoints([]);
        setIsEditing(true);
        setLoading(false);
        return;
      }
      setLoading(true);
      setError("");
      try {
        const response = await fetch(`http://127.0.0.1:5000/api/templates/${templateId}`);
        if (!response.ok) throw new Error(`Failed to fetch template (${response.status})`);
        const data = await response.json();
        if (isMounted) {
          setTemplate(data);
          setEditName(data.template_name || data.name || "");
          setEditContent(data.template_content || "");
          setEditDataPoints(data.data_points || []);
        }
      } catch (err) {
        if (isMounted) setError(err.message || "Failed to load template.");
      } finally {
        if (isMounted) setLoading(false);
      }
    };
    fetchTemplate();
    return () => { isMounted = false; };
  }, [templateId]);

  const handleSave = async () => {
    setSaving(true);
    setError("");
    try {
      const url = templateId === 'new' 
        ? `http://127.0.0.1:5000/api/templates` 
        : `http://127.0.0.1:5000/api/templates/${templateId}`;
      
      const method = templateId === 'new' ? "POST" : "PUT";

      const response = await fetch(url, {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          template_name: editName,
          template_content: editContent,
          data_points: editDataPoints
        }),
      });
      if (!response.ok) throw new Error(`Failed to save template (${response.status})`);
      
      if (templateId === 'new') {
        alert("Template created successfully!");
        onBack(); // Go back to list
      } else {
        setTemplate({ ...template, template_name: editName, template_content: editContent, data_points: editDataPoints });
        setIsEditing(false);
      }
    } catch (err) {
      setError(err.message || "Failed to save template.");
    } finally {
      setSaving(false);
    }
  };

  const addDataPoint = () => {
    if (!newField.trim()) return;
    setEditDataPoints([...editDataPoints, { field: newField.trim(), prompt: newPrompt.trim() }]);
    setNewField("");
    setNewPrompt("");
  };

  const removeDataPoint = (idx) => {
    setEditDataPoints(editDataPoints.filter((_, i) => i != idx));
  };

  const updateDp = (idx, key, val) => {
    const updated = [...editDataPoints];
    updated[idx] = { ...updated[idx], [key]: val };
    setEditDataPoints(updated);
  };

  if (loading) return <div className="templates-state">Loading template details...</div>;
  if (error) return <div className="templates-state error">{error}</div>;
  if (!template) return <div className="templates-state error">Template not found.</div>;

  return (
    <div className="templates-shell" style={{ animation: 'fadeIn 0.3s ease' }}>
      <div className="template-editor-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 24 }}>
        <button
          className="btn-ghost"
          onClick={onBack}
          style={{ display: 'flex', alignItems: 'center', gap: 6, color: 'var(--text-dim)', padding: '8px 12px', borderRadius: 8 }}
        >
          &larr; Back to Templates
        </button>
        <div className="template-editor-actions" style={{ display: 'flex', gap: 12 }}>
          {isEditing ? (
            <>
              <div className="de-vtoggle" style={{ marginRight: 12 }}>
                <button
                  className={`de-vt${activeTab === "overview" ? " active" : ""}`}
                  onClick={() => setActiveTab("overview")}
                >
                  Overview
                </button>
                <button
                  className={`de-vt${activeTab === "datapoints" ? " active" : ""}`}
                  onClick={() => setActiveTab("datapoints")}
                >
                  Data Points
                </button>
              </div>
              <button className="btn-ghost" onClick={() => {
                if (templateId === 'new') {
                  onBack();
                  return;
                }
                setIsEditing(false);
                setEditName(template.template_name || template.name || "");
                setEditContent(template.template_content || "");
                setEditDataPoints(template.data_points || []);
              }} disabled={saving} style={{ padding: '8px 16px', borderRadius: 8 }}>Cancel</button>
              <button className="btn-primary" onClick={handleSave} disabled={saving} style={{ background: 'var(--cyan)', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: 8, fontWeight: 500, boxShadow: '0 2px 8px var(--cyan-glow)' }}>
                {saving ? "Saving..." : "Save Changes"}
              </button>
            </>
          ) : (
            <>
              <button className="btn-ghost" onClick={() => { setIsEditing(true); setActiveTab("overview"); }} style={{ padding: '8px 16px', borderRadius: 8, border: '1px solid var(--border)', background: 'var(--surface)' }}>Edit Template</button>
              <button className="btn-ghost" onClick={() => { setIsEditing(true); setActiveTab("datapoints"); }} style={{ padding: '8px 16px', borderRadius: 8, border: '1px solid var(--border)', background: 'var(--surface)' }}>Add Data Points</button>
              <button className="btn-primary" onClick={() => onUseTemplate(template)} style={{ background: 'var(--cyan)', color: '#fff', border: 'none', padding: '8px 16px', borderRadius: 8, fontWeight: 500, boxShadow: '0 2px 8px var(--cyan-glow)' }}>
                Use Template
              </button>
            </>
          )}
        </div>
      </div>

      <div className="template-editor-body" style={{ padding: 32, background: 'var(--surface)', borderRadius: 16, border: '1px solid var(--border)', boxShadow: '0 4px 12px rgba(0,0,0,0.02)' }}>
        {isEditing ? (
          activeTab === "overview" ? (
            <div className="template-edit-form" style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
              <div>
                <label style={{ display: 'block', marginBottom: 8, fontWeight: 500, fontSize: 13, color: 'var(--text-dim)' }}>Template Name</label>
                <input
                  className="de-dp-field-input"
                  style={{ width: '100%', padding: '12px 16px', fontSize: 16, fontWeight: 600, borderRadius: 8, border: '1px solid var(--border)', background: 'var(--bg)' }}
                  value={editName}
                  onChange={e => setEditName(e.target.value)}
                />
              </div>
              <div>
                <label style={{ display: 'block', marginBottom: 8, fontWeight: 500, fontSize: 13, color: 'var(--text-dim)' }}>Extraction Prompt (Content)</label>
                <textarea
                  className="de-dp-prompt-input"
                  style={{ width: '100%', minHeight: 400, padding: 16, fontFamily: 'var(--mono)', fontSize: 13, lineHeight: 1.6, borderRadius: 8, border: '1px solid var(--border)', background: 'var(--bg)', resize: 'vertical' }}
                  value={editContent}
                  onChange={e => setEditContent(e.target.value)}
                />
              </div>
            </div>
          ) : (
            <div className="template-datapoints-edit">
              <div className="de-step-hd" style={{ marginBottom: 20 }}>
                <div className="de-step-title">Configure Template Data Points</div>
                <div className="de-step-sub">Define the fields and specific instructions for this template</div>
              </div>

              <div className="de-dp-add-row" style={{ marginBottom: 24 }}>
                <input
                  type="text"
                  className="de-dp-field-input"
                  placeholder="Field Name (e.g. Total Amount)"
                  value={newField}
                  onChange={e => setNewField(e.target.value)}
                />
                <textarea
                  className="de-dp-prompt-input"
                  placeholder="Extraction Instruction..."
                  rows={1}
                  value={newPrompt}
                  onChange={e => setNewPrompt(e.target.value)}
                />
                <button className="de-dp-add-btn" onClick={addDataPoint} style={{ height: 'fit-content' }}>Add</button>
              </div>

              <div className="de-dp-list">
                {editDataPoints.map((dp, idx) => (
                  <div key={idx} className="de-dp-item" style={{ marginBottom: 12 }}>
                    <div className="de-dp-item-head">
                      <div className="de-dp-item-num">{String(idx + 1).padStart(2, '0')}</div>
                      <div className="de-dp-item-name">
                        <input
                          value={dp.field}
                          onChange={e => updateDp(idx, 'field', e.target.value)}
                        />
                      </div>
                      <button 
                        type="button"
                        className="de-dp-delete-btn" 
                        onClick={(e) => { e.stopPropagation(); e.preventDefault(); removeDataPoint(idx); }}
                      >
                        ✕
                      </button>
                    </div>
                    <div className="de-dp-item-body open">
                      <textarea
                        className="de-dp-item-textarea"
                        value={dp.prompt}
                        onChange={e => updateDp(idx, 'prompt', e.target.value)}
                        placeholder="Instruction..."
                      />
                    </div>
                  </div>
                ))}
                {editDataPoints.length === 0 && (
                  <div className="de-dp-empty">No data points defined for this template.</div>
                )}
              </div>
            </div>
          )
        ) : (
          <div className="template-view">
            <h2 style={{ marginBottom: 8, fontSize: 24, fontWeight: 600, color: 'var(--text)', letterSpacing: '-0.01em' }}>
              {template.template_name || template.name || "Untitled Template"}
            </h2>
            <p style={{ fontSize: 14, color: 'var(--text-dim)', marginBottom: 24 }}>
              Extraction configuration rules and prompt instructions.
            </p>
            
            <div className="template-tabs" style={{ display: 'flex', gap: 24, borderBottom: '1px solid var(--border)', marginBottom: 24 }}>
               <button 
                className={`tab-btn ${activeTab === 'overview' ? 'active' : ''}`}
                onClick={() => setActiveTab('overview')}
                style={{ padding: '8px 4px', background: 'none', border: 'none', borderBottom: activeTab === 'overview' ? '2px solid var(--cyan)' : '2px solid transparent', color: activeTab === 'overview' ? 'var(--cyan)' : 'var(--text-dim)', cursor: 'pointer', fontWeight: 500 }}
               >Overview</button>
               <button 
                className={`tab-btn ${activeTab === 'datapoints' ? 'active' : ''}`}
                onClick={() => setActiveTab('datapoints')}
                style={{ padding: '8px 4px', background: 'none', border: 'none', borderBottom: activeTab === 'datapoints' ? '2px solid var(--cyan)' : '2px solid transparent', color: activeTab === 'datapoints' ? 'var(--cyan)' : 'var(--text-dim)', cursor: 'pointer', fontWeight: 500 }}
               >Data Points ({editDataPoints.length})</button>
            </div>

            {activeTab === 'overview' ? (
              <div className="template-content-preview" style={{ background: 'var(--bg)', border: '1px solid var(--border)', padding: 24, borderRadius: 12, overflowX: 'auto' }}>
                <pre style={{ margin: 0, whiteSpace: 'pre-wrap', wordWrap: 'break-word', fontFamily: 'var(--mono)', fontSize: 13, color: 'var(--text)', lineHeight: 1.6 }}>
                  {template.template_content}
                </pre>
              </div>
            ) : (
              <div className="template-datapoints-preview">
                <div className="de-dp-list">
                  {editDataPoints.map((dp, idx) => (
                    <div key={idx} className="de-dp-item" style={{ marginBottom: 12, opacity: 0.9 }}>
                      <div className="de-dp-item-head">
                        <div className="de-dp-item-num">{String(idx + 1).padStart(2, '0')}</div>
                        <div className="de-dp-item-name">
                          <div style={{ padding: '8px 12px', fontWeight: 500 }}>{dp.field}</div>
                        </div>
                      </div>
                      <div className="de-dp-item-body open">
                        <div style={{ padding: '12px', fontSize: 13, color: 'var(--text-secondary)', lineHeight: 1.5, background: 'rgba(255,255,255,0.02)', borderRadius: 8 }}>
                          {dp.prompt || <span style={{ fontStyle: 'italic', color: 'var(--text-dim)' }}>No instruction provided.</span>}
                        </div>
                      </div>
                    </div>
                  ))}
                  {editDataPoints.length === 0 && (
                    <div className="de-dp-empty">No data points defined.</div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function TemplatesPage({ onUseTemplate }) {
  const [selectedTemplateId, setSelectedTemplateId] = useState(null);
  const [initialTab, setInitialTab] = useState("overview");
  const [templates, setTemplates] = useState([]);
  const [loadingTemplates, setLoadingTemplates] = useState(true);
  const [templatesError, setTemplatesError] = useState("");

  useEffect(() => {
    let isMounted = true;

    const fetchTemplates = async () => {
      setLoadingTemplates(true);
      setTemplatesError("");
      try {
        const response = await fetch("http://127.0.0.1:5000/api/templates");
        if (!response.ok) {
          throw new Error(`Failed to fetch templates (${response.status})`);
        }
        const data = await response.json();
        const list = Array.isArray(data) ? data : Array.isArray(data.templates) ? data.templates : [];
        if (isMounted) setTemplates(list);
      } catch (err) {
        if (isMounted) {
          setTemplates([]);
          setTemplatesError(err.message || "Failed to load templates.");
        }
      } finally {
        if (isMounted) setLoadingTemplates(false);
      }
    };

    fetchTemplates();
    return () => {
      isMounted = false;
    };
  }, []);

  const handleDeleteTemplate = async (e, templateId) => {
    e.stopPropagation();
    if (!window.confirm("Are you sure you want to delete this template? This action cannot be undone.")) {
      return;
    }

    try {
      const response = await fetch(`http://127.0.0.1:5000/api/templates/${templateId}`, {
        method: "DELETE",
      });

      if (!response.ok) {
        throw new Error(`Failed to delete template (${response.status})`);
      }

      setTemplates((prev) => prev.filter((t) => t.id !== templateId));
      console.log(`Successfully deleted template ${templateId}`);
    } catch (err) {
      alert("Error deleting template: " + err.message);
    }
  };

  const getFields = (template) => {
    if (Array.isArray(template.data_points)) {
      return template.data_points.map((dp) => (typeof dp === "string" ? dp : dp?.field || "")).filter(Boolean);
    }
    if (Array.isArray(template.fields)) return template.fields;
    return [];
  };

  const getUpdatedText = (template) => {
    const raw = template.updated_at || template.created_at || template.timestamp;
    if (!raw) return "Recently";
    const d = new Date(raw);
    if (Number.isNaN(d.getTime())) return "Recently";
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
  };

  const getDescription = (template, fields) => {
    if (template.description && String(template.description).trim()) return template.description;
    const lead = template.name || template.template_name || "This template";
    const fieldWords = fields.slice(0, 3).join(", ");
    return fieldWords
      ? `${lead} extraction focused on ${fieldWords.toLowerCase()}.`
      : `${lead} extraction configuration for document processing.`;
  };

  const getRelatedWords = (template, fields) => {
    if (fields && fields.length > 0) {
      return fields.slice(0, 6);
    }
    const fromName = String(template.name || template.template_name || "")
      .split(/[\s-_]+/)
      .map((w) => w.trim())
      .filter((w) => w.length > 2);
    return [...new Set(fromName)].slice(0, 6);
  };

  if (selectedTemplateId) {
    return (
      <TemplateEditor
        templateId={selectedTemplateId}
        initialTab={initialTab}
        onBack={() => { setSelectedTemplateId(null); setInitialTab("overview"); }}
        onUseTemplate={onUseTemplate}
      />
    );
  }

  return (
    <div className="templates-shell">
      <div className="templates-head">
        <div>
          <h1>Templates</h1>
          <p>Reusable extraction configurations for common document types</p>
        </div>
        <button className="templates-new-btn" onClick={() => setSelectedTemplateId('new')}>
          <Plus size={14} />
          New Template
        </button>
      </div>

      {loadingTemplates ? (
        <div className="templates-state">Loading templates...</div>
      ) : templatesError ? (
        <div className="templates-state error">{templatesError}</div>
      ) : templates.length === 0 ? (
        <div className="templates-state">No templates available from API.</div>
      ) : (
        <div className="templates-grid">
          {templates.map((template, idx) => {
            const fields = getFields(template);
            const visibleFields = fields.slice(0, 5);
            const moreCount = Math.max(fields.length - visibleFields.length, 0);
            
            const getTemplateTheme = (name) => {
              const lower = String(name).toLowerCase();
              const baseTheme = {
                bg: '#f8fafc',
                color: '#475569',
                tagBg: '#f1f5f9',
                tagColor: '#475569',
                tagBorder: '1px solid #cbd5e170'
              };

              if (lower.includes('health')) return { 
                icon: <Activity size={18} strokeWidth={1.8} />, 
                ...baseTheme
              };
              if (lower.includes('financ')) return { 
                icon: <DollarSign size={18} strokeWidth={1.8} />, 
                ...baseTheme
              };
              if (lower.includes('msa')) return { 
                icon: <ShieldCheck size={18} strokeWidth={1.8} />, 
                ...baseTheme
              };
              if (lower.includes('sow')) return { 
                icon: <FileText size={18} strokeWidth={1.8} />, 
                ...baseTheme
              };
              return { 
                icon: <LayoutGrid size={18} strokeWidth={1.8} />, 
                ...baseTheme
              };
            };
            const theme = getTemplateTheme(template.name || template.template_name || "");

            return (
              <div
                className="template-card"
                key={template.id || template.name || idx}
                onClick={() => setSelectedTemplateId(template.id)}
                role="button"
                tabIndex={0}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    onUseTemplate?.(template);
                  }
                }}
              >
                <div className="template-card-top">
                  <div className="template-card-header">
                    <span className="template-icon" style={{ backgroundColor: theme.bg, color: theme.color }}>
                      {theme.icon}
                    </span>
                    <div className="template-card-top-actions">
                      <button
                        className="template-card-use-btn"
                        onClick={(e) => {
                          e.stopPropagation();
                          onUseTemplate?.(template);
                        }}
                      >
                        Use
                      </button>
                    </div>
                  </div>
                  <h3>{template.name || template.template_name || "Untitled Template"}</h3>
                  <p>{getDescription(template, fields)}</p>
                </div>

                <div className="template-tags">
                  {getRelatedWords(template, visibleFields).map((field) => (
                    <span key={field} className="template-tag" style={{ backgroundColor: theme.tagBg, color: theme.tagColor, border: theme.tagBorder }}>
                      {field}
                    </span>
                  ))}
                  {moreCount > 0 && <span className="template-tag" style={{ backgroundColor: '#f8fafc', color: '#94a3b8', border: '1px solid #cbd5e170' }}>+{moreCount} more</span>}
                </div>

                <div className="template-card-foot">
                  <span><Users size={14} /> {fields.length} fields</span>
                  <span><Calendar size={14} /> {getUpdatedText(template)}</span>
                  <div className="template-card-actions">
                    <button
                      className="template-card-delete-btn"
                      onClick={(e) => {
                        e.stopPropagation();
                        e.preventDefault();
                        handleDeleteTemplate(e, template.id);
                      }}
                    >
                      <Trash2 size={14} /> Delete
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ── COMPONENT ─────────────────────────────────────────────────────────────────
export default function DocExtract({ onLogout }) {
  // State
  const [files, setFiles] = useState([]);           // multi-file array
  const [dataPoints, setDataPoints] = useState([]);
  const [newField, setNewField] = useState("");
  const [newPrompt, setNewPrompt] = useState("");
  const [dragging, setDragging] = useState(false);
  const [expanded, setExpanded] = useState({});
  const [result, setResult] = useState(null);
  const [view, setView] = useState("cards");
  const [loading, setLoading] = useState(false);
  const [prog, setProg] = useState({ show: false, pct: 0, msg: "" });
  const [error, setError] = useState("");
  const [copiedJSON, setCopiedJSON] = useState(false);
  const [selectedPreset, setSelectedPreset] = useState([]);
  const [preset, setPreset] = useState("");
  const [activeNav, setActiveNav] = useState("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [settingsTab, setSettingsTab] = useState("Billings");
  const [notifications, setNotifications] = useState([
    {
      id: 1,
      title: "Extraction Successful",
      description: "medical_field.pdf was processed and 4/4 fields were extracted.",
      time: "2 hours ago",
      unread: true,
      type: "success"
    },
    {
      id: 2,
      title: "Review Required",
      description: "invoice_9918.pdf contains 2 fields flagged with low confidence scores.",
      time: "5 hours ago",
      unread: true,
      type: "warning"
    },
    {
      id: 3,
      title: "Storage Warning",
      description: "Your workspace has used 65% of the allocated storage limit.",
      time: "1 day ago",
      unread: false,
      type: "info"
    },
    {
      id: 4,
      title: "Integrations Reconnected",
      description: "Google Drive account was successfully reconnected by Alex Johnson.",
      time: "2 days ago",
      unread: false,
      type: "success"
    }
  ]);
  const [verifyMode, setVerifyMode] = useState(false);
  const [verifiedFields, setVerifiedFields] = useState({}); // { fieldKey: "approved"|"flagged"|"pending" }
  const [editedResult, setEditedResult] = useState({});     // { fieldKey: editedValue }
  const [flagNotes, setFlagNotes] = useState({});           // { fieldKey: noteString }
  const [pdfUrls, setPdfUrls] = useState({});       // { filename: blobUrl }
  const [uploadSource, setUploadSource] = useState("local");
  const [driveModalOpen, setDriveModalOpen] = useState(false);
  const [driveFiles, setDriveFiles] = useState([]);
  const [driveLoading, setDriveLoading] = useState(false);
  const [driveError, setDriveError] = useState("");
  const [driveSearch, setDriveSearch] = useState("");
  const [driveSelectingId, setDriveSelectingId] = useState(null);
  const [driveConnected, setDriveConnected] = useState(false);

  const [oneDriveModalOpen, setOneDriveModalOpen] = useState(false);
  const [oneDriveFiles, setOneDriveFiles] = useState([]);
  const [oneDriveLoading, setOneDriveLoading] = useState(false);
  const [oneDriveError, setOneDriveError] = useState("");
  const [oneDriveSearch, setOneDriveSearch] = useState("");
  const [oneDriveSelectingId, setOneDriveSelectingId] = useState(null);
  const [oneDriveConnected, setOneDriveConnected] = useState(false);
  const [activeFileIdx, setActiveFileIdx] = useState(0);
  const [summary, setSummary] = useState(null);
  const [activeField, setActiveField] = useState(null);       // { name, value } currently highlighted
  const [pdfSearchText, setPdfSearchText] = useState("");

  useEffect(() => {
    // Clear results when file or data points change
    setSelectedPreset(PRESETS_POLICY_CHECKING);

  }, []);
 
  const fileInputRef = useRef(null);
  const resultSecRef = useRef(null);

  // ── Derived ────────────────────────────────────────────────────────────────
  const withPrompts = dataPoints.filter((d) => d.prompt.trim()).length;
  const missingCount = dataPoints.length - withPrompts;
  const canRun =
    files.length > 0 &&
    dataPoints.length > 0 &&
    dataPoints.every((d) => d.field.trim() && d.prompt.trim());

  // ── File Handling ──────────────────────────────────────────────────────────
  const ALLOWED_TYPES = [
  "application/pdf",
  "image/png",
  "image/jpeg",
  "image/jpg",
  "image/webp",
  "image/tiff"
];
  const applyFile = useCallback((f) => {
  if (!f) return;
  if (ALLOWED_TYPES.includes(f.type)) {
    setFiles(prev => prev.find(x => x.name === f.name) ? prev : [...prev, f]);
  } else {
    setError("Only PDF, PNG, JPG, JPEG, WEBP, and TIFF files are supported.");
  }
}, []);

  const switchUploadSource = (source) => {
    setUploadSource(source);
    setError("");
    clearFile();
    if (source === "drive") {
      setDriveError("");
    } else if (source === "onedrive") {
      setOneDriveError("");
    } else {
      setDriveModalOpen(false);
      setDriveSearch("");
      setOneDriveModalOpen(false);
      setOneDriveSearch("");
    }
  };

  // clearFile(name) removes one file by name; clearFile() clears all
  const clearFile = (name) => {
    if (name) {
      setFiles(prev => prev.filter(f => f.name !== name));
    } else {
      setFiles([]);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const onDragOver = (e) => { e.preventDefault(); setDragging(true); };
  const onDragLeave = () => setDragging(false);
  const onDrop = (e) => { e.preventDefault(); setDragging(false); Array.from(e.dataTransfer.files).forEach(applyFile); };
  const onFileChange = (e) => { Array.from(e.target.files || []).forEach(applyFile); };

  const fetchDriveFiles = async () => {
    setDriveLoading(true);
    setDriveError("");
    try {
      const statusRes = await fetch(`${BACKEND_URL}/auth/status`, { credentials: "include" });
      const statusData = await statusRes.json().catch(() => ({}));
      const connected = Boolean(statusData.connected);
      setDriveConnected(connected);

      if (!connected) {
        setDriveFiles([]);
        setDriveError("Connect Google Drive in Integrations first.");
        return;
      }

      const res = await fetch(`${BACKEND_URL}/drive/files`, { credentials: "include" });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(data.error || "Failed to load Drive files.");
      }

      setDriveFiles(Array.isArray(data.files) ? data.files : []);
    } catch (err) {
      setDriveError(err.message || "Failed to load Drive files.");
    } finally {
      setDriveLoading(false);
    }
  };

  const openDrivePicker = async () => {
    setDriveModalOpen(true);
    setDriveSearch("");
    await fetchDriveFiles();
  };

  const closeDrivePicker = () => {
    setDriveModalOpen(false);
    setDriveSearch("");
    setDriveError("");
  };

  const importDriveFile = async (driveFile) => {
    setDriveSelectingId(driveFile.id);
    setDriveError("");
    try {
      const res = await fetch(`${BACKEND_URL}/drive/files/${encodeURIComponent(driveFile.id)}`, {
        credentials: "include",
      });

      const blob = await res.blob();
      if (!res.ok) {
        const message = await blob.text().catch(() => "");
        throw new Error(message || "Failed to download Drive file.");
      }

      const pdfFile = new File(
        [blob],
        driveFile.name.toLowerCase().endsWith(".pdf") ? driveFile.name : `${driveFile.name}.pdf`,
        { type: "application/pdf" }
      );

      applyFile(pdfFile);
      setDriveModalOpen(false);
      setDriveSearch("");
      setError("");
    } catch (err) {
      setDriveError(err.message || "Failed to import Drive file.");
    } finally {
      setDriveSelectingId(null);
    }
  };

  const filteredDriveFiles = driveFiles.filter((item) =>
    item.name.toLowerCase().includes(driveSearch.trim().toLowerCase())
  );

  const fetchOneDriveFiles = async () => {
    setOneDriveLoading(true);
    setOneDriveError("");
    try {
      const statusRes = await fetch(`${BACKEND_URL}/onedrive/auth/status`, { credentials: "include" });
      const statusData = await statusRes.json().catch(() => ({}));
      const connected = Boolean(statusData.connected);
      setOneDriveConnected(connected);

      if (!connected) {
        setOneDriveFiles([]);
        setOneDriveError("Connect Microsoft OneDrive in Integrations first.");
        return;
      }

      const res = await fetch(`${BACKEND_URL}/onedrive/files`, { credentials: "include" });
      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        throw new Error(data.error || "Failed to load OneDrive files.");
      }

      setOneDriveFiles(Array.isArray(data.files) ? data.files : []);
    } catch (err) {
      setOneDriveError(err.message || "Failed to load OneDrive files.");
    } finally {
      setOneDriveLoading(false);
    }
  };

  const openOneDrivePicker = async () => {
    setOneDriveModalOpen(true);
    setOneDriveSearch("");
    await fetchOneDriveFiles();
  };

  const closeOneDrivePicker = () => {
    setOneDriveModalOpen(false);
    setOneDriveSearch("");
    setOneDriveError("");
  };

  const importOneDriveFile = async (oneDriveFile) => {
    setOneDriveSelectingId(oneDriveFile.id);
    setOneDriveError("");
    try {
      const res = await fetch(`${BACKEND_URL}/onedrive/files/${encodeURIComponent(oneDriveFile.id)}`, {
        credentials: "include",
      });

      const blob = await res.blob();
      if (!res.ok) {
        const message = await blob.text().catch(() => "");
        throw new Error(message || "Failed to download OneDrive file.");
      }

      const pdfFile = new File(
        [blob],
        oneDriveFile.name.toLowerCase().endsWith(".pdf") ? oneDriveFile.name : `${oneDriveFile.name}.pdf`,
        { type: "application/pdf" }
      );

      applyFile(pdfFile);
      setOneDriveModalOpen(false);
      setOneDriveSearch("");
      setError("");
    } catch (err) {
      setOneDriveError(err.message || "Failed to import OneDrive file.");
    } finally {
      setOneDriveSelectingId(null);
    }
  };

  const filteredOneDriveFiles = oneDriveFiles.filter((item) =>
    item.name.toLowerCase().includes(oneDriveSearch.trim().toLowerCase())
  );

  const useTemplateForExtraction = (template) => {
    const name = template?.name || template?.template_name || "";
    const apiDataPoints = Array.isArray(template?.data_points) ? template.data_points : [];
    const apiFields = Array.isArray(template?.fields) ? template.fields : [];
    const normalized = (apiDataPoints.length > 0 ? apiDataPoints : apiFields).map((item) => {
      if (typeof item === "string") {
        return { id: nextId(), field: item, prompt: "" };
      }
      return {
        id: nextId(),
        field: item?.field || item?.name || "",
        prompt: item?.prompt || item?.instruction || "",
      };
    }).filter((dp) => dp.field.trim());

    setDataPoints(normalized);
    setExpanded(Object.fromEntries(normalized.map((dp) => [dp.id, !dp.prompt])));
    setPreset(name);
    setResult(null);
    setError("");
    setVerifyMode(false);
    setActiveNav("extraction");
  };

  // ── Data Points ────────────────────────────────────────────────────────────
  const addDataPoint = (field, prompt) => {
    const f = (field ?? newField).trim();
    const p = (prompt ?? newPrompt).trim();
    if (!f) return;
    const id = nextId();
    setDataPoints((prev) => [...prev, { id, field: f, prompt: p }]);
    setExpanded((prev) => ({ ...prev, [id]: !p }));
    if (field === undefined) {
      setNewField("");
      setNewPrompt("");
    }
  };

  const handlePresetChange = (e) => {
    const presetValue = e.target.value;
    if (!presetValue) return;  // No selection

    if (presetValue === "Invoice Checking") {
      setSelectedPreset(PRESETS_POLICY_CHECKING);
    } else if (presetValue === "Financial Statements") {
      setSelectedPreset(PRESETS_FINANCE);
    }
    else if (presetValue === "Legal Documents") {
      setSelectedPreset(PRESETS_LEGAL);
    }
    else if (presetValue === "Health Care Documents") {
      setSelectedPreset(PRESETS_HEALTHCARE_DOCUMENTS);
    }
    else if (presetValue === "MSA Extraction") {
      setSelectedPreset(PRESETS_MSA_EXTRACTION);
    }
    else if (presetValue === "SOW Extraction") {
      setSelectedPreset(PRESETS_SOW_EXTRACTION);
    }
    else {
      return;
    }
    setPreset(presetValue);
  };

  const addPreset = (field, prompt) => {
    if (dataPoints.find((d) => d.field.toLowerCase() === field.toLowerCase())) return;
    addDataPoint(field, prompt);
  };

  const removeDataPoint = (id) => {
    setDataPoints((prev) => prev.filter((d) => d.id != id));
    setExpanded((prev) => { const n = { ...prev }; delete n[id]; return n; });
  };

  const updateDpField = (id, val) => setDataPoints((prev) => prev.map((d) => (d.id === id ? { ...d, field: val } : d)));
  const updateDpPrompt = (id, val) => setDataPoints((prev) => prev.map((d) => (d.id === id ? { ...d, prompt: val } : d)));
  const toggleExpand = (id) => setExpanded((prev) => ({ ...prev, [id]: !prev[id] }));

  // ── Extraction ─────────────────────────────────────────────────────────────
  const runExtraction = async () => {
    console.log(localStorage.getItem("id"))
    console.log("the user id is ", localStorage.getItem("id"))
    if (files.length === 0) {
      setError("Please upload at least one PDF file.");
      return;
    }
    const missing = dataPoints.filter((d) => !d.prompt.trim());
    if (missing.length > 0) {
      setError(
        `Missing prompts for: ${missing.map((d) => `"${d.field}"`).join(", ")}. Please add a prompt for every field.`
      );
      return;
    }

    setError("");
    setLoading(true);
    setProg({ show: true, pct: 8, msg: `Uploading ${files.length} PDF${files.length > 1 ? "s" : ""}…` });

    const payload = dataPoints.map((d) => ({ field: d.field.trim(), prompt: d.prompt.trim() }));
    const fd = new FormData();
    files.forEach(f => fd.append("file", f));   // ← all files under key "pdf"
    fd.append("upload_source", uploadSource);
    fd.append("file_size", files.reduce((acc, f) => acc + f.size, 0));
    fd.append("file_count", files.length);
    fd.append("file_type", "mixed");
    fd.append("user_id", localStorage.getItem("id") || "");
    fd.append("data_points", JSON.stringify(payload));
    fd.append("preset", preset);
    

    try {
      setProg({ show: true, pct: 25, msg: `Extracting text from ${files.length} PDF${files.length > 1 ? "s" : ""} (OCR if needed)…` });

      let resp;
      try {
        resp = await fetch("http://localhost:5000/api/extract", { method: "POST", body: fd });
      } catch (fetchErr) {
        throw new Error(`Network error: ${fetchErr.message}. Is the backend running on localhost:5000?`);
      }

      setProg({ show: true, pct: 70, msg: `Running AI extraction — ${payload.length} fields × ${files.length} file(s)…` });

      let data;
      try {
        data = await resp.json();
      } catch (jsonErr) {
        throw new Error(`Failed to parse response: ${jsonErr.message}`);
      }

      if (!resp.ok) throw new Error(data.error || `Server error ${resp.status}`);
      if (data.error) throw new Error(data.error);
      if (!data.results) throw new Error("Invalid response: no results returned from server");

      setProg({ show: true, pct: 100, msg: "Rendering results…" });

      // data.results = { "filename.pdf": { extracted_fields: {...}, file_status, processing_time }, ... }
      setResult(data.results);
      setSummary(data.summary);
      setActiveFileIdx(0);
      setActiveField(null);
      setPdfSearchText("");

      // Init verify state — key: "filename::fieldName"
      const initEdited = {}, initVerified = {};
      Object.entries(data.results).forEach(([filename, fileResult]) => {
        if (fileResult.file_status === "success") {
          Object.entries(fileResult.extracted_fields || {}).forEach(([key, val]) => {
            const sk = `${filename}::${key}`;
            initEdited[sk] = val == null ? "" : typeof val === "object" ? JSON.stringify(val, null, 2) : String(val);
            initVerified[sk] = "pending";
          });
        }
      });
      setEditedResult(initEdited);
      setVerifiedFields(initVerified);
      setFlagNotes({});

      // Build blob URLs for every uploaded file
      const urls = {};
      files.forEach(f => { urls[f.name] = URL.createObjectURL(f); });
      setPdfUrls(urls);

      setTimeout(() => setProg({ show: false, pct: 0, msg: "" }), 500);
      setTimeout(() => setVerifyMode(true), 600);
    } catch (err) {
      setProg({ show: false, pct: 0, msg: "" });
      setError(err.message || "Extraction failed. Is the backend running on localhost:5000?");
    } finally {
      setLoading(false);
    }
  };

  // ── Copy / Download ────────────────────────────────────────────────────────
  const copyJSON = () => {
    if (!result) return;
    navigator.clipboard
      .writeText(JSON.stringify(result, null, 2))
      .then(() => { setCopiedJSON(true); setTimeout(() => setCopiedJSON(false), 1400); });
  };

  const downloadExcel = () => {
    if (!result) return;
    const wb = XLSX.utils.book_new();
    Object.entries(result).forEach(([filename, fileResult]) => {
      if (fileResult.file_status !== "success") return;
      const wsData = [["Field", "Value"]];
      Object.entries(fileResult.extracted_fields || {}).forEach(([k, v]) => {
        const cellValue = v == null ? "null" : typeof v === "object" ? JSON.stringify(v) : String(v);
        wsData.push([k, cellValue]);
      });
      const ws = XLSX.utils.aoa_to_sheet(wsData);
      ws["!cols"] = [{ wch: 25 }, { wch: 50 }];
      // Sheet name max 31 chars
      const sheetName = filename.replace(/\.pdf$/i, "").substring(0, 31);
      XLSX.utils.book_append_sheet(wb, ws, sheetName);
    });
    XLSX.writeFile(wb, "extraction_results.xlsx");
  };

  // ── Verify helpers ─────────────────────────────────────────────────────────
  const setFieldStatus = (key, status) =>
    setVerifiedFields((prev) => ({ ...prev, [key]: status }));

  const setFieldValue = (key, val) =>
    setEditedResult((prev) => ({ ...prev, [key]: val }));

  const setFieldNote = (key, note) =>
    setFlagNotes((prev) => ({ ...prev, [key]: note }));

  const approveAll = () => {
    // Approve only the currently active file's fields
    if (!result) return;
    const activeFileName = Object.keys(result)[activeFileIdx];
    if (!activeFileName) return;
    const fields = Object.keys(result[activeFileName]?.extracted_fields || {});
    setVerifiedFields(prev => {
      const next = { ...prev };
      fields.forEach(key => { next[`${activeFileName}::${key}`] = "approved"; });
      return next;
    });
  };

  const saveJson = async () => {
    try {
      if (!activeFileName || !activeFileResult) {
        throw new Error("No active file selected for saving.");
      }

      if (activeFileResult.file_status !== "success") {
        throw new Error("Only successful extractions can be saved.");
      }

      const out = {};
      Object.keys(activeFileResult.extracted_fields || {}).forEach((key) => {
        const sk = `${activeFileName}::${key}`;
        out[key] = {
          value: editedResult[sk] ?? "",
          status: verifiedFields[sk] || "pending",
          note: flagNotes[sk] || "",
        };
      });

      const res = await fetch("http://localhost:5000/api/save_result_status", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          file_name: activeFileName,
          out,
        }),
      });

      if (!res.ok) {
        throw new Error(`Server error ${res.status}`);
      }

      const r = await res.json();
      alert(r.message || "Results saved successfully.");
    } catch (err) {
      console.error(err);
      alert("Failed to save results: " + err.message);
    }
  };

  const exportVerified = () => {
    if (!result) return;
    const out = {};
    Object.entries(result).forEach(([filename, fileResult]) => {
      if (fileResult.file_status !== "success") return;
      out[filename] = {};
      Object.keys(fileResult.extracted_fields || {}).forEach(key => {
        const sk = `${filename}::${key}`;
        out[filename][key] = {
          value: editedResult[sk] ?? "",
          status: verifiedFields[sk] || "pending",
          note: flagNotes[sk] || "",
        };
      });
    });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(out, null, 2)], { type: "application/json" }));
    a.download = "extraction_verified.json";
    a.click();
  };

  const backToExtraction = () => {
    setVerifyMode(false);
  };

  // ── Render ─────────────────────────────────────────────────────────────────
  // Active-file context for verify/results panels
  const resultFileNames = result ? Object.keys(result) : [];
  const activeFileName = resultFileNames[activeFileIdx] || "";
  const activeFileResult = result ? result[activeFileName] : null;
  const activeExtractedFields = activeFileResult?.extracted_fields || {};

  // For the old results section (table/json view) — show active file
  const resultEntries = Object.entries(activeExtractedFields);
  const resultFilename = activeFileName ? activeFileName.replace(/\.pdf$/i, "") + "_result.json" : "result.json";

  // For the verify screen — per active file, using scoped keys "filename::fieldName"
  const verifyEntries = Object.entries(activeExtractedFields).map(([key]) => {
    const sk = `${activeFileName}::${key}`;
    return [sk, editedResult[sk] ?? ""];
  });

  // Global counts across all files
  const approvedCount = Object.values(verifiedFields).filter((s) => s === "approved").length;
  const flaggedCount  = Object.values(verifiedFields).filter((s) => s === "flagged").length;
  const pendingCount  = Object.values(verifiedFields).filter((s) => s === "pending").length;

  const navItems = [
    {
      id: "dashboard",
      label: "Dashboard",
      icon: (
        <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.8" stroke="currentColor" width="16" height="16">
          <rect x="3" y="3" width="7" height="7" rx="1" /><rect x="14" y="3" width="7" height="7" rx="1" />
          <rect x="3" y="14" width="7" height="7" rx="1" /><rect x="14" y="14" width="7" height="7" rx="1" />
        </svg>
      ),
    },
    {
      id: "extraction",
      label: "New Extraction",
      icon: (
        <svg viewBox="0 0 24 24" fill="none" strokeWidth="2" stroke="currentColor" width="16" height="16">
          <path d="M12 5v14M5 12h14" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      id: "templates",
      label: "Templates",
      icon: (
        <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.8" stroke="currentColor" width="16" height="16">
          <path d="M4 19.5A2.5 2.5 0 016.5 17H20" /><path d="M6.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15A2.5 2.5 0 016.5 2z" />
        </svg>
      ),
    },
    {
      id: "integrations",
      label: "Integrations",
      icon: (
        <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.8" stroke="currentColor" width="16" height="16">
          <circle cx="8" cy="8" r="3" /><circle cx="16" cy="16" r="3" />
          <path d="M10.5 10.5l3 3" strokeLinecap="round" />
          <path d="M8 5V3M8 13v2M5 8H3M13 8h2" strokeLinecap="round" />
        </svg>
      ),
    },
    {
      id: "history",
      label: "History",
      icon: (
        <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.8" stroke="currentColor" width="16" height="16">
          <path d="M12 8v4l3 3" strokeLinecap="round" />
          <path d="M3.05 11a9 9 0 1 0 .5-4" strokeLinecap="round" />
          <path d="M3 4v4h4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      ),
    },
  ];

  return (
    <div className={`de-root${sidebarCollapsed ? " sidebar-collapsed" : ""}`}>

      {/* ── SIDEBAR ── */}
      <aside className="de-sidebar">
        <div className="de-sb-top">
          <div className="de-sb-logo">
            {!sidebarCollapsed && (
              <div className="de-sb-logo-inner">
                <div className="de-sb-logo-box">
                  <BrainCircuit size={20} />
                </div>
                <span className="de-sb-brand">Doc<span>Extract</span></span>
              </div>
            )}
            <button className="de-sb-toggle" onClick={() => setSidebarCollapsed(v => !v)} title="Toggle sidebar">
              <svg
                viewBox="0 0 24 24"
                fill="none"
                strokeWidth="2"
                stroke="currentColor"
                width="18"
                height="18"
                style={{
                  transition: 'transform 0.3s ease',
                  transform: sidebarCollapsed ? 'rotate(180deg)' : 'rotate(0deg)'
                }}
              >
                <path d="M15 18l-6-6 6-6" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </button>
          </div>

          <nav className="de-sb-nav">
            {navItems.map((item) => (
              <button
                key={item.id}
                className={`de-sb-nav-item${activeNav === item.id ? " active" : ""}`}
                onClick={() => setActiveNav(item.id)}
                title={sidebarCollapsed ? item.label : ""}
              >
                <span className="de-sb-nav-icon">{item.icon}</span>
                {!sidebarCollapsed && <span className="de-sb-nav-label">{item.label}</span>}
              </button>
            ))}
          </nav>
        </div>

        <div className="de-sb-bottom">
          <button
            className={`de-sb-nav-item${activeNav === "settings" ? " active" : ""}`}
            onClick={() => setActiveNav("settings")}
            title={sidebarCollapsed ? "Settings" : ""}
          >
            <span className="de-sb-nav-icon">
              <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.8" stroke="currentColor" width="16" height="16">
                <circle cx="12" cy="12" r="3" />
                <path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 010 2.83 2 2 0 01-2.83 0l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06A1.65 1.65 0 004.68 15a1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06A1.65 1.65 0 009 4.68a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06A1.65 1.65 0 0019.4 9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z" />
              </svg>
            </span>
            {!sidebarCollapsed && <span className="de-sb-nav-label">Settings</span>}
          </button>

          {!sidebarCollapsed && (
            <div className="de-sb-usage">
              <div className="de-sb-usage-label">USAGE</div>
              <div className="de-sb-usage-bar-wrap">
                <div className="de-sb-usage-bar" style={{ width: "65%" }} />
              </div>
              <div className="de-sb-usage-text">650 / 1000 Extractions left</div>
            </div>
          )}

          {onLogout && (
            <button
              type="button"
              className="de-sb-nav-item"
              onClick={onLogout}
              title={sidebarCollapsed ? "Logout" : ""}
              style={{ marginTop: "12px", color: "#ef4444" }}
            >
              <span className="de-sb-nav-icon">
                <svg viewBox="0 0 24 24" fill="none" strokeWidth="1.8" stroke="currentColor" width="16" height="16">
                  <path d="M10 17l5-5-5-5" strokeLinecap="round" strokeLinejoin="round" />
                  <path d="M15 12H3" strokeLinecap="round" />
                  <path d="M21 3v18" strokeLinecap="round" />
                </svg>
              </span>
              {!sidebarCollapsed && <span className="de-sb-nav-label">Logout</span>}
            </button>
          )}
        </div>
      </aside>

      {/* ── MAIN ── */}
      <div className="de-main">
        {/* Conditional rendering based on activeNav */}
        {activeNav === "extraction" && (
          <NewExtractionUI
            files={files}
            dataPoints={dataPoints}
            setDataPoints={setDataPoints}
            setPreset={setPreset}
            newField={newField}
            setNewField={setNewField}
            newPrompt={newPrompt}
            setNewPrompt={setNewPrompt}
            dragging={dragging}
            expanded={expanded}
            result={result}
            view={view}
            setView={setView}
            loading={loading}
            prog={prog}
            error={error}
            selectedPreset={selectedPreset}
            preset={preset}
            verifyMode={verifyMode}
            fileInputRef={fileInputRef}
            resultSecRef={resultSecRef}
            copiedJSON={copiedJSON}
            withPrompts={withPrompts}
            missingCount={missingCount}
            canRun={canRun}
            resultEntries={resultEntries}
            resultFilename={resultFilename}
            verifyEntries={verifyEntries}
            approvedCount={approvedCount}
            flaggedCount={flaggedCount}
            pendingCount={pendingCount}
            verifiedFields={verifiedFields}
            editedResult={editedResult}
            flagNotes={flagNotes}
            pdfUrls={pdfUrls}
            activeFileIdx={activeFileIdx}
            setActiveFileIdx={setActiveFileIdx}
            activeFileName={activeFileName}
            resultFileNames={resultFileNames}
            activeFileResult={activeFileResult}
            summary={summary}
            activeField={activeField}
            setActiveField={setActiveField}
            pdfSearchText={pdfSearchText}
            setPdfSearchText={setPdfSearchText}
            onDragOver={onDragOver}
            onDragLeave={onDragLeave}
            onDrop={onDrop}
            onFileChange={onFileChange}
            clearFile={clearFile}
            applyFile={applyFile}
            addDataPoint={addDataPoint}
            handlePresetChange={handlePresetChange}
            addPreset={addPreset}
            removeDataPoint={removeDataPoint}
            updateDpField={updateDpField}
            updateDpPrompt={updateDpPrompt}
            toggleExpand={toggleExpand}
            runExtraction={runExtraction}
            copyJSON={copyJSON}
            downloadExcel={downloadExcel}
            setFieldStatus={setFieldStatus}
            setFieldValue={setFieldValue}
            setFieldNote={setFieldNote}
            approveAll={approveAll}
            saveJson={saveJson}
            exportVerified={exportVerified}
            backToExtraction={backToExtraction}
            setVerifyMode={setVerifyMode}
            setActiveNav={setActiveNav}
            uploadSource={uploadSource}
            switchUploadSource={switchUploadSource}
            openDrivePicker={openDrivePicker}
            driveModalOpen={driveModalOpen}
            closeDrivePicker={closeDrivePicker}
            driveSearch={driveSearch}
            setDriveSearch={setDriveSearch}
            driveLoading={driveLoading}
            driveError={driveError}
            driveConnected={driveConnected}
            filteredDriveFiles={filteredDriveFiles}
            importDriveFile={importDriveFile}
            driveSelectingId={driveSelectingId}
            openOneDrivePicker={openOneDrivePicker}
            oneDriveModalOpen={oneDriveModalOpen}
            closeOneDrivePicker={closeOneDrivePicker}
            oneDriveSearch={oneDriveSearch}
            setOneDriveSearch={setOneDriveSearch}
            oneDriveLoading={oneDriveLoading}
            oneDriveError={oneDriveError}
            oneDriveConnected={oneDriveConnected}
            filteredOneDriveFiles={filteredOneDriveFiles}
            importOneDriveFile={importOneDriveFile}
            oneDriveSelectingId={oneDriveSelectingId}
          />
        )}

        {/* Dashboard - Empty for now */}
        {activeNav === "dashboard" && (
          <Dashboard
            setActiveNav={setActiveNav}
            setSettingsTab={setSettingsTab}
            notifications={notifications}
            setNotifications={setNotifications}
          />
        )}

        {/* Templates - Empty for now */}
        {activeNav === "templates" && (
          <TemplatesPage onUseTemplate={useTemplateForExtraction} />
        )}

        {/* Integrations - Empty for now */}
        {activeNav === "integrations" && (
          <Integration />
        )}

        {/* History - Empty for now */}
        {activeNav === "history" && (
          <History />
        )}

        {/* Settings - Empty for now */}
        {activeNav === "settings" && (
          <SettingsPage
            activeTab={settingsTab}
            setActiveTab={setSettingsTab}
            notifications={notifications}
            setNotifications={setNotifications}
          />
        )}

        {/* Profile */}
        {activeNav === "profile" && (
          <Profile />
        )}
      </div> {/* end de-main */}
    </div>
  );
}